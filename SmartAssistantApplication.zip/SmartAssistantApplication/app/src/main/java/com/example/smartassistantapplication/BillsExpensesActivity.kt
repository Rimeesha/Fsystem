package com.example.smartassistantapplication

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class BillsExpensesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var db: ExpenseDatabaseHelper
    private lateinit var adapter: ExpenseAdapter
    private lateinit var expenseList: ArrayList<ExpenseModel>

    private lateinit var tvTotal: TextView
    private lateinit var pieChart: PieChartView
    private lateinit var btnAddExpense: FloatingActionButton

    // BOTTOM MENU
    private lateinit var navHome: TextView
    private lateinit var navTask: TextView
    private lateinit var navGrocery: TextView
    private lateinit var navBills: TextView
    private lateinit var navMeal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bills_expenses)

        recyclerView = findViewById(R.id.rvExpenses)
        tvTotal = findViewById(R.id.tvTotal)
        pieChart = findViewById(R.id.pieChart)
        btnAddExpense = findViewById(R.id.btnAddExpense)

        // BOTTOM MENU IDS
        navHome = findViewById(R.id.nav_home)
        navTask = findViewById(R.id.nav_task)
        navGrocery = findViewById(R.id.nav_grocery)
        navBills = findViewById(R.id.nav_bill)
        navMeal = findViewById(R.id.nav_meal)

        recyclerView.layoutManager = LinearLayoutManager(this)
        db = ExpenseDatabaseHelper(this)

        btnAddExpense.setOnClickListener {
            startActivity(Intent(this, AddExpenseActivity::class.java))
        }

        setupBottomMenu()
        highlightSelected(R.id.nav_bill)

        loadExpenses()
    }

    override fun onResume() {
        super.onResume()
        loadExpenses()
        highlightSelected(R.id.nav_bill)
    }

    private fun loadExpenses() {

        expenseList = db.getAllExpenses()

        var total = 0.0
        for (exp in expenseList) {
            total += exp.amount
        }

        tvTotal.text = "Total: RM %.2f".format(total)

        // PIE CHART
        val categoryMap = mutableMapOf<String, Double>()

        for (exp in expenseList) {
            categoryMap[exp.category] =
                (categoryMap[exp.category] ?: 0.0) + exp.amount
        }

        pieChart.setData(categoryMap)

        // ADAPTER
        adapter = ExpenseAdapter(
            expenseList,
            object : ExpenseAdapter.OnItemClickListener {

                override fun onItemClick(expense: ExpenseModel) {

                    val intent = Intent(
                        this@BillsExpensesActivity,
                        EditExpenseActivity::class.java
                    )

                    intent.putExtra("expense_id", expense.id)
                    intent.putExtra("name", expense.name)
                    intent.putExtra("category", expense.category)
                    intent.putExtra("amount", expense.amount)
                    intent.putExtra("date", expense.date)

                    startActivity(intent)
                }
            }
        )

        recyclerView.adapter = adapter

        // SWIPE DELETE
        val itemTouchHelperCallback =
            object : ItemTouchHelper.SimpleCallback(
                0,
                ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
            ) {

                override fun onMove(
                    recyclerView: RecyclerView,
                    viewHolder: RecyclerView.ViewHolder,
                    target: RecyclerView.ViewHolder
                ): Boolean {
                    return false
                }

                override fun onSwiped(
                    viewHolder: RecyclerView.ViewHolder,
                    direction: Int
                ) {

                    val pos = viewHolder.adapterPosition
                    val expense = expenseList[pos]

                    db.deleteExpense(expense.id)

                    expenseList.removeAt(pos)

                    adapter.notifyItemRemoved(pos)

                    Toast.makeText(
                        this@BillsExpensesActivity,
                        "Deleted",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        ItemTouchHelper(itemTouchHelperCallback)
            .attachToRecyclerView(recyclerView)
    }

    // =========================
    // BOTTOM MENU
    // =========================

    private fun setupBottomMenu() {

        navHome.setOnClickListener {
            highlightSelected(R.id.nav_home)
            startActivity(Intent(this, HomeActivity::class.java))
        }

        navTask.setOnClickListener {
            highlightSelected(R.id.nav_task)
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        navGrocery.setOnClickListener {
            highlightSelected(R.id.nav_grocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        navBills.setOnClickListener {
            highlightSelected(R.id.nav_bill)
        }

        navMeal.setOnClickListener {
            highlightSelected(R.id.nav_meal)
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }
    }

    // =========================
    // HIGHLIGHT MENU
    // =========================

    private fun highlightSelected(selectedId: Int) {

        val items = listOf(
            navHome,
            navTask,
            navGrocery,
            navBills,
            navMeal
        )

        val selectedBg = Color.parseColor("#2196F3")
        val defaultBg = Color.TRANSPARENT

        for (item in items) {
            item.setBackgroundColor(defaultBg)
            item.setTextColor(Color.WHITE)
        }

        val selectedView = when (selectedId) {

            R.id.nav_home -> items[0]

            R.id.nav_task -> items[1]

            R.id.nav_grocery -> items[2]

            R.id.nav_bill -> items[3]

            R.id.nav_meal -> items[4]

            else -> items[3]
        }

        // FULL HIGHLIGHT
        selectedView.setBackgroundColor(selectedBg)
        selectedView.setTextColor(Color.BLACK)
    }
}
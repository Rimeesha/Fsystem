package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar

class OrderHistoryActivity : AppCompatActivity() {

    lateinit var recycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_order_history)

        recycler = findViewById(R.id.orderRecycler)

        loadOrders()

        val topBar = findViewById<MaterialToolbar>(R.id.topBar)

        topBar.setNavigationOnClickListener {
            startActivity(Intent(this, GroceryActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        loadOrders()
    }

    fun loadOrders() {
        val db = OrderDatabaseHelper(this)
        val list = db.getAllOrders()

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = OrderAdapter(list, this)
    }
}
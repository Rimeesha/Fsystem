package com.example.smartassistantapplication

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar

class ProductDetailActivity : AppCompatActivity() {

    private val parentPin = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        val topBar = findViewById<MaterialToolbar>(R.id.topBar)

        val productImage = findViewById<ImageView>(R.id.productImage)
        val productName = findViewById<TextView>(R.id.productName)
        val productPrice = findViewById<TextView>(R.id.productPrice)
        val productDesc = findViewById<TextView>(R.id.productDesc)
        val productRating = findViewById<TextView>(R.id.productRating)
        val quantityText = findViewById<TextView>(R.id.quantityText)
        val plusBtn = findViewById<Button>(R.id.plusBtn)
        val minusBtn = findViewById<Button>(R.id.minusBtn)
        val nextBtn = findViewById<Button>(R.id.nextBtn)

        // ✅ BACK BUTTON
        topBar.setNavigationOnClickListener {
            finish()
        }

        // RECEIVE DATA
        val name = intent.getStringExtra("name") ?: "Product"
        val priceText = intent.getStringExtra("price") ?: "RM 0"
        val desc = intent.getStringExtra("desc") ?: ""
        val rating = intent.getStringExtra("rating") ?: "0"
        val image = intent.getIntExtra("image", 0)

        productName.text = name
        productDesc.text = desc
        productRating.text = "Rating: $rating"

        if (image != 0) productImage.setImageResource(image)

        val basePrice = priceText.replace("RM", "").trim().toDoubleOrNull() ?: 0.0
        var qty = 1

        fun updatePrice() {
            val total = basePrice * qty
            productPrice.text = "RM %.2f".format(total)
            quantityText.text = qty.toString()
        }

        updatePrice()

        plusBtn.setOnClickListener { qty++; updatePrice() }
        minusBtn.setOnClickListener { if (qty > 1) { qty--; updatePrice() } }

        nextBtn.setOnClickListener {
            val category = detectCategory(name)

            if (category == "School" || category == "Play") {
                showPinDialog(name, basePrice, qty, image)
            } else {
                goToCheckout(name, basePrice, qty, image)
            }
        }
    }

    private fun showPinDialog(name: String, price: Double, qty: Int, image: Int) {
        val pinEditText = EditText(this)
        pinEditText.inputType =
            android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD

        AlertDialog.Builder(this)
            .setTitle("Parent Approval Required")
            .setMessage("Enter PIN to continue")
            .setView(pinEditText)
            .setPositiveButton("Approve") { _: DialogInterface, _: Int ->
                val enteredPin = pinEditText.text.toString()
                if (enteredPin == parentPin) {
                    goToCheckout(name, price, qty, image)
                } else {
                    Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun goToCheckout(name: String, price: Double, qty: Int, image: Int) {
        val intent = Intent(this, CheckoutActivity::class.java)

        val totalPrice = price * qty

        intent.putExtra("name", name)
        intent.putExtra("price", totalPrice)
        intent.putExtra("qty", qty)
        intent.putExtra("image", image)

        startActivity(intent)
    }

    private fun detectCategory(name: String): String {
        return when (name.lowercase()) {
            "pencil", "notebook", "eraser" -> "School"
            "toy car", "ball", "lego" -> "Play"
            else -> "Grocery"
        }
    }
}
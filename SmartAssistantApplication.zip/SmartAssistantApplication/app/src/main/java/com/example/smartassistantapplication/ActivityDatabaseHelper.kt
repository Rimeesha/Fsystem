package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ActivityDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "activities.db"
        private const val DATABASE_VERSION = 2 // bumped version for new tables

        // Activity Table
        private const val TABLE_NAME = "activities"
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_DURATION = "duration"
        private const val COL_CALORIES = "calories"

        // Water Intake Table
        private const val TABLE_WATER = "WaterIntake"
        private const val COL_WATER_ID = "id"
        private const val COL_WATER_DATE = "date"
        private const val COL_WATER_GLASSES = "glasses"

        // BMI Records Table
        private const val TABLE_BMI = "BMIRecords"
        private const val COL_BMI_ID = "id"
        private const val COL_BMI_DATE = "date"
        private const val COL_BMI_VALUE = "bmi"
        private const val COL_BMI_CATEGORY = "category"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Activity Table
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NAME TEXT,
                $COL_DURATION INTEGER,
                $COL_CALORIES INTEGER
            )
        """.trimIndent()
        db?.execSQL(createTable)

        // Water Intake Table
        val createWaterTable = """
            CREATE TABLE IF NOT EXISTS $TABLE_WATER (
                $COL_WATER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_WATER_DATE TEXT UNIQUE,
                $COL_WATER_GLASSES INTEGER
            )
        """.trimIndent()
        db?.execSQL(createWaterTable)

        // BMI Records Table
        val createBMITable = """
            CREATE TABLE IF NOT EXISTS $TABLE_BMI (
                $COL_BMI_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_BMI_DATE TEXT UNIQUE,
                $COL_BMI_VALUE REAL,
                $COL_BMI_CATEGORY TEXT
            )
        """.trimIndent()
        db?.execSQL(createBMITable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // Add new tables on upgrade
            val createWaterTable = """
                CREATE TABLE IF NOT EXISTS $TABLE_WATER (
                    $COL_WATER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COL_WATER_DATE TEXT UNIQUE,
                    $COL_WATER_GLASSES INTEGER
                )
            """.trimIndent()
            db?.execSQL(createWaterTable)

            val createBMITable = """
                CREATE TABLE IF NOT EXISTS $TABLE_BMI (
                    $COL_BMI_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COL_BMI_DATE TEXT UNIQUE,
                    $COL_BMI_VALUE REAL,
                    $COL_BMI_CATEGORY TEXT
                )
            """.trimIndent()
            db?.execSQL(createBMITable)
        }
    }

    // -------------------- Activity Functions --------------------
    fun addActivity(item: ActivityItem): Long {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put(COL_NAME, item.name)
        cv.put(COL_DURATION, item.duration)
        cv.put(COL_CALORIES, item.calories)
        return db.insert(TABLE_NAME, null, cv)
    }

    fun getAllActivities(): List<ActivityItem> {
        val list = mutableListOf<ActivityItem>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)
        if (cursor.moveToFirst()) {
            do {
                val item = ActivityItem(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
                    duration = cursor.getInt(cursor.getColumnIndexOrThrow(COL_DURATION)),
                    calories = cursor.getInt(cursor.getColumnIndexOrThrow(COL_CALORIES))
                )
                list.add(item)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun updateActivity(item: ActivityItem): Int {
        val db = writableDatabase
        val cv = ContentValues()
        cv.put(COL_NAME, item.name)
        cv.put(COL_DURATION, item.duration)
        cv.put(COL_CALORIES, item.calories)
        return db.update(TABLE_NAME, cv, "$COL_ID = ?", arrayOf(item.id.toString()))
    }

    fun deleteActivity(id: Int): Int {
        val db = writableDatabase
        return db.delete(TABLE_NAME, "$COL_ID = ?", arrayOf(id.toString()))
    }

    // -------------------- Water Intake Functions --------------------
    fun addOrUpdateWaterIntake(date: String, glasses: Int) {
        val db = writableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_WATER WHERE $COL_WATER_DATE = ?", arrayOf(date))
        val values = ContentValues().apply { put(COL_WATER_GLASSES, glasses) }

        if (cursor.moveToFirst()) {
            db.update(TABLE_WATER, values, "$COL_WATER_DATE=?", arrayOf(date))
        } else {
            values.put(COL_WATER_DATE, date)
            db.insert(TABLE_WATER, null, values)
        }
        cursor.close()
    }

    fun getWaterIntake(date: String): Int {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COL_WATER_GLASSES FROM $TABLE_WATER WHERE $COL_WATER_DATE=?", arrayOf(date))
        val glasses = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return glasses
    }

    // -------------------- BMI Functions --------------------
    fun addOrUpdateBMI(date: String, bmi: Float, category: String) {
        val db = writableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_BMI WHERE $COL_BMI_DATE = ?", arrayOf(date))
        val values = ContentValues().apply {
            put(COL_BMI_VALUE, bmi)
            put(COL_BMI_CATEGORY, category)
        }

        if (cursor.moveToFirst()) {
            db.update(TABLE_BMI, values, "$COL_BMI_DATE=?", arrayOf(date))
        } else {
            values.put(COL_BMI_DATE, date)
            db.insert(TABLE_BMI, null, values)
        }
        cursor.close()
    }

    fun getBMI(date: String): Pair<Float, String>? {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COL_BMI_VALUE, $COL_BMI_CATEGORY FROM $TABLE_BMI WHERE $COL_BMI_DATE=?", arrayOf(date))
        val result = if (cursor.moveToFirst()) {
            Pair(cursor.getFloat(0), cursor.getString(1))
        } else null
        cursor.close()
        return result
    }
}
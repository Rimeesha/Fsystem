package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.bottomnavigation.BottomNavigationView

class EditExpenseActivity : AppCompatActivity() {

    private lateinit var db: ExpenseDatabaseHelper
    private var expenseId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_expense)

        // =========================
        // TOOLBAR (BACK BUTTON)
        // =========================
        val topBar = findViewById<Toolbar>(R.id.topBar)
        setSupportActionBar(topBar)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        topBar.setNavigationOnClickListener {
            finish() // back to Bills & Expenses page
        }

        // =========================
        // DATABASE
        // =========================
        db = ExpenseDatabaseHelper(this)

        // =========================
        // FIND VIEWS
        // =========================
        val etName = findViewById<EditText>(R.id.etName)
        val etCategory = findViewById<EditText>(R.id.etCategory)
        val etAmount = findViewById<EditText>(R.id.etAmount)
        val etDate = findViewById<EditText>(R.id.etDate)
        val btnSave = findViewById<Button>(R.id.btnSave)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        // =========================
        // GET DATA FROM INTENT
        // =========================
        expenseId = intent.getIntExtra("expense_id", -1)
        etName.setText(intent.getStringExtra("name") ?: "")
        etCategory.setText(intent.getStringExtra("category") ?: "")
        etAmount.setText(intent.getDoubleExtra("amount", 0.0).toString())
        etDate.setText(intent.getStringExtra("date") ?: "")

        // =========================
        // SAVE BUTTON
        // =========================
        btnSave.setOnClickListener {

            val name = etName.text.toString().trim()
            val category = etCategory.text.toString().trim()
            val amountText = etAmount.text.toString().trim()
            val date = etDate.text.toString().trim()

            if(name.isEmpty() || category.isEmpty() || amountText.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val amount = try {
                amountText.toDouble()
            } catch(e: Exception) {
                Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            db.updateExpense(expenseId, name, category, amount, date)
            Toast.makeText(this, "Expense Updated", Toast.LENGTH_SHORT).show()

            finish() // go back to Bills page
        }

        // =========================
        // BOTTOM NAVIGATION
        // =========================
        bottomNav.selectedItemId = R.id.nav_bills

        bottomNav.setOnItemSelectedListener {

            when(it.itemId){

                R.id.nav_tasks -> {
                    startActivity(Intent(this, CalendarActivity::class.java))
                    true
                }

                R.id.nav_grocery -> {
                    startActivity(Intent(this, GroceryActivity::class.java))
                    true
                }

                R.id.nav_bills -> {
                    true // already here
                }

                R.id.nav_meals -> {
                    startActivity(Intent(this, MealPlannerActivity::class.java))
                    true
                }

                R.id.nav_health -> {
                    startActivity(Intent(this, HealthActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }
}
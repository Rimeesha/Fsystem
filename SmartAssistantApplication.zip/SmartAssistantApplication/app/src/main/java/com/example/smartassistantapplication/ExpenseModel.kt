package com.example.smartassistantapplication

data class ExpenseModel(
    val id: Int,
    val name: String,
    val category: String,
    val amount: Double,
    val date: String
)
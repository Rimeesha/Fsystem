package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.bottomnavigation.BottomNavigationView

class MealDetailActivity : AppCompatActivity() {

    private lateinit var topBar: Toolbar
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var imgMeal: ImageView
    private lateinit var tvMealName: TextView
    private lateinit var tvIngredients: TextView
    private lateinit var tvNutrition: TextView
    private lateinit var tvPreparation: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_detail)

        // =========================
        // INIT VIEWS
        // =========================
        topBar = findViewById(R.id.topBar)
        bottomNav = findViewById(R.id.bottomNav)
        imgMeal = findViewById(R.id.imgMeal)
        tvMealName = findViewById(R.id.tvMealName)
        tvIngredients = findViewById(R.id.tvIngredients)
        tvNutrition = findViewById(R.id.tvNutrition)
        tvPreparation = findViewById(R.id.tvPreparation)

        // =========================
        // TOOLBAR
        // =========================
        setSupportActionBar(topBar)

        supportActionBar?.title = "Meal Detail"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        topBar.setNavigationOnClickListener {
            finish()
        }

        // =========================
        // GET MEAL NAME
        // =========================
        val mealName = intent.getStringExtra("MEAL_NAME") ?: "Nasi Lemak"

        tvMealName.text = mealName

        // =========================
        // SET IMAGE
        // =========================
        when (mealName.lowercase()) {

            "nasi lemak" -> {
                imgMeal.setImageResource(R.drawable.nasilemak)
            }

            "fried rice" -> {
                imgMeal.setImageResource(R.drawable.friedrice)
            }

            "chicken rice" -> {
                imgMeal.setImageResource(R.drawable.chickenrice)
            }

            "roti canai" -> {
                imgMeal.setImageResource(R.drawable.roticanai)
            }

            "mee goreng" -> {
                imgMeal.setImageResource(R.drawable.meegoreng)
            }

            else -> {
                imgMeal.setImageResource(R.drawable.nasilemak)
            }
        }

        // =========================
        // LOAD DETAILS
        // =========================
        val details = getMealDetails(mealName)

        tvIngredients.text = details["ingredients"]
        tvNutrition.text = details["nutrition"]
        tvPreparation.text = details["preparation"]

        // =========================
        // BOTTOM NAVIGATION
        // =========================
        setupBottomNavigation()
    }

    // =========================
    // BOTTOM NAVIGATION
    // =========================
    private fun setupBottomNavigation() {

        bottomNav.selectedItemId = R.id.nav_meals

        bottomNav.setOnItemSelectedListener { item ->

            when (item.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }

                R.id.nav_tasks -> {
                    startActivity(Intent(this, CalendarActivity::class.java))
                    true
                }

                R.id.nav_grocery -> {
                    startActivity(Intent(this, GroceryActivity::class.java))
                    true
                }

                R.id.nav_bills -> {
                    startActivity(Intent(this, BillsExpensesActivity::class.java))
                    true
                }

                R.id.nav_meals -> {
                    true
                }

                R.id.nav_health -> {
                    startActivity(Intent(this, HealthActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }

    // =========================
    // MEAL DETAILS
    // =========================
    private fun getMealDetails(mealName: String): Map<String, String> {

        return when (mealName.lowercase()) {

            // =========================
            // NASI LEMAK
            // =========================
            "nasi lemak" -> mapOf(

                "ingredients" to
                        "🍚 Rice\n" +
                        "🥥 Coconut Milk\n" +
                        "💧 Water\n" +
                        "🧂 Salt\n" +
                        "🌿 Pandan Leaves\n\n" +

                        "🌶 Sambal:\n" +
                        "• Dried Chili\n" +
                        "• Onion\n" +
                        "• Garlic\n" +
                        "• Belacan\n" +
                        "• Tamarind Paste\n" +
                        "• Sugar\n\n" +

                        "🍳 Side Items:\n" +
                        "• Boiled Egg\n" +
                        "• Cucumber\n" +
                        "• Fried Anchovies\n" +
                        "• Peanuts",

                "nutrition" to
                        "🔥 650 kcal\n" +
                        "💪 Protein: 20g\n" +
                        "🥑 Fat: 28g\n" +
                        "🍞 Carbohydrates: 70g",

                "preparation" to
                        "1. Wash rice thoroughly.\n\n" +
                        "2. Add coconut milk, water, salt and pandan leaves.\n\n" +
                        "3. Cook rice until fluffy.\n\n" +
                        "4. Blend dried chili, onion and garlic.\n\n" +
                        "5. Fry sambal paste until fragrant.\n\n" +
                        "6. Add belacan, tamarind and sugar.\n\n" +
                        "7. Cook until sambal thickens.\n\n" +
                        "8. Fry anchovies until crispy.\n\n" +
                        "9. Serve with egg, cucumber, peanuts and sambal."
            )

            // =========================
            // FRIED RICE
            // =========================
            "fried rice" -> mapOf(

                "ingredients" to
                        "🍚 Rice\n" +
                        "🥚 Egg\n" +
                        "🥕 Vegetables\n" +
                        "🧄 Garlic\n" +
                        "🧅 Onion\n" +
                        "🧂 Soy Sauce\n" +
                        "🌶 Chili",

                "nutrition" to
                        "🔥 520 kcal\n" +
                        "💪 Protein: 15g\n" +
                        "🍞 Carbohydrates: 60g",

                "preparation" to
                        "1. Heat oil in a pan.\n\n" +
                        "2. Fry garlic and onion.\n\n" +
                        "3. Add vegetables and egg.\n\n" +
                        "4. Add rice and soy sauce.\n\n" +
                        "5. Stir fry until hot and fragrant."
            )

            // =========================
            // CHICKEN RICE
            // =========================
            "chicken rice" -> mapOf(

                "ingredients" to
                        "🍗 Chicken\n" +
                        "🍚 Rice\n" +
                        "🧄 Garlic\n" +
                        "🫚 Ginger\n" +
                        "🥒 Cucumber\n" +
                        "🧂 Soy Sauce",

                "nutrition" to
                        "🔥 600 kcal\n" +
                        "💪 Protein: 30g\n" +
                        "🍞 Carbohydrates: 55g",

                "preparation" to
                        "1. Boil chicken until cooked.\n\n" +
                        "2. Cook rice with chicken broth.\n\n" +
                        "3. Slice chicken neatly.\n\n" +
                        "4. Serve with cucumber and sauce."
            )

            // =========================
            // ROTI CANAI
            // =========================
            "roti canai" -> mapOf(

                "ingredients" to
                        "🌾 Flour\n" +
                        "🧈 Butter\n" +
                        "🧂 Salt\n" +
                        "💧 Water\n" +
                        "🥚 Egg",

                "nutrition" to
                        "🔥 300 kcal\n" +
                        "🍞 Carbohydrates: 40g\n" +
                        "🥑 Fat: 10g",

                "preparation" to
                        "1. Mix flour, salt and water.\n\n" +
                        "2. Knead dough until smooth.\n\n" +
                        "3. Flatten and fold dough.\n\n" +
                        "4. Fry on hot pan until crispy."
            )

            // =========================
            // MEE GORENG
            // =========================
            "mee goreng" -> mapOf(

                "ingredients" to
                        "🍜 Yellow Noodles\n" +
                        "🥚 Egg\n" +
                        "🧄 Garlic\n" +
                        "🧅 Onion\n" +
                        "🌶 Chili Sauce\n" +
                        "🥬 Vegetables",

                "nutrition" to
                        "🔥 550 kcal\n" +
                        "💪 Protein: 18g\n" +
                        "🍞 Carbohydrates: 65g",

                "preparation" to
                        "1. Fry garlic and onion.\n\n" +
                        "2. Add vegetables and egg.\n\n" +
                        "3. Add noodles and sauces.\n\n" +
                        "4. Stir fry until well mixed."
            )

            // =========================
            // DEFAULT
            // =========================
            else -> mapOf(

                "ingredients" to "N/A",

                "nutrition" to "N/A",

                "preparation" to "N/A"
            )
        }
    }
}
package com.example.smartassistantapplication

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MealAdapter(
    private val meals: List<Meal>,
    private val onEditClick: (Meal) -> Unit,
    private val onDeleteClick: (Meal) -> Unit
) : RecyclerView.Adapter<MealAdapter.MealViewHolder>() {

    inner class MealViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val imgMeal: ImageView = view.findViewById(R.id.imgMeal)

        val tvMealType: TextView = view.findViewById(R.id.tvMealType)

        val tvMealName: TextView = view.findViewById(R.id.tvMealName)

        val tvCalories: TextView = view.findViewById(R.id.tvCalories)

        val btnEdit: Button = view.findViewById(R.id.btnEdit)

        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_meal, parent, false)

        return MealViewHolder(view)
    }

    override fun getItemCount(): Int = meals.size

    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {

        val meal = meals[position]

        // =========================
        // SET TEXT
        // =========================
        holder.tvMealType.text = meal.mealType

        holder.tvMealName.text = meal.mealName

        holder.tvCalories.text = "🔥 ${meal.calories} kcal"

        // =========================
        // SET IMAGE
        // =========================
        when (meal.mealName.lowercase()) {

            "nasi lemak" -> {
                holder.imgMeal.setImageResource(R.drawable.nasilemak)
            }

            "fried rice" -> {
                holder.imgMeal.setImageResource(R.drawable.friedrice)
            }

            "chicken rice" -> {
                holder.imgMeal.setImageResource(R.drawable.chickenrice)
            }

            "roti canai" -> {
                holder.imgMeal.setImageResource(R.drawable.roticanai)
            }

            "mee goreng" -> {
                holder.imgMeal.setImageResource(R.drawable.meegoreng)
            }

            else -> {
                holder.imgMeal.setImageResource(R.drawable.nasilemak)
            }
        }

        // =========================
        // BUTTONS
        // =========================
        holder.btnEdit.setOnClickListener {
            onEditClick(meal)
        }

        holder.btnDelete.setOnClickListener {
            onDeleteClick(meal)
        }

        // =========================
        // OPEN DETAIL PAGE
        // =========================
        holder.itemView.setOnClickListener {

            val context = holder.itemView.context

            val intent = Intent(context, MealDetailActivity::class.java)

            intent.putExtra("MEAL_NAME", meal.mealName)

            intent.putExtra("MEAL_TYPE", meal.mealType)

            intent.putExtra("MEAL_CALORIES", meal.calories)

            context.startActivity(intent)
        }
    }
}
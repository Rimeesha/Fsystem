package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TaskDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "tasks_db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("""
            CREATE TABLE tasks(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                date TEXT,
                time TEXT
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS tasks")
        onCreate(db)
    }

    // Add a new task
    fun addTask(task: Task): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("title", task.title)
            put("description", task.description)
            put("date", task.date)
            put("time", task.time)
        }
        val id = db.insert("tasks", null, values)
        db.close()
        return id
    }

    // Get all tasks
    fun getAllTasks(): ArrayList<Task> {
        val list = ArrayList<Task>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM tasks ORDER BY id DESC", null)
        if (cursor.moveToFirst()) {
            do {
                val task = Task(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    title = cursor.getString(cursor.getColumnIndexOrThrow("title")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    time = cursor.getString(cursor.getColumnIndexOrThrow("time"))
                )
                list.add(task)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    // Delete a task by ID
    fun deleteTask(id: Int) {
        val db = writableDatabase
        db.delete("tasks", "id=?", arrayOf(id.toString()))
        db.close()
    }

    // Update an existing task
    fun updateTask(task: Task): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("title", task.title)
            put("description", task.description)
            put("date", task.date)
            put("time", task.time)
        }
        val rows = db.update("tasks", values, "id=?", arrayOf(task.id.toString()))
        db.close()
        return rows
    }
}
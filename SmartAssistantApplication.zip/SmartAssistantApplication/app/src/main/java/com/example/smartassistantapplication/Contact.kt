package com.example.smartassistantapplication

data class Contact(
    val name: String,
    val phone: String
)
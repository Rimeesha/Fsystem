package com.example.smartassistantapplication

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

class PieChartView(context: Context, attrs: AttributeSet) : View(context, attrs) {

    companion object {
        val colors = listOf(
            Color.parseColor("#4CAF50"), // Food
            Color.parseColor("#F44336"), // House
            Color.parseColor("#FF9800"), // Transport
            Color.parseColor("#2196F3"), // Bills
            Color.parseColor("#9C27B0")  // Others
        )
    }

    private var data: Map<String, Double> = mapOf()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setData(data: Map<String, Double>) {
        this.data = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) return

        val total = data.values.sum()
        var startAngle = -90f
        val size = min(width, height)
        val padding = 50f
        val radius = size / 2f - padding
        val cx = width / 2f
        val cy = height / 2f

        var i = 0
        for ((_, value) in data) {
            val sweepAngle = (value / total * 360).toFloat()
            paint.color = colors[i % colors.size]
            canvas.drawArc(cx - radius, cy - radius, cx + radius, cy + radius,
                startAngle, sweepAngle, true, paint)
            startAngle += sweepAngle
            i++
        }

        paint.color = Color.BLACK
        paint.textSize = 40f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Spending", cx, cy + radius + 50f, paint)
    }
}
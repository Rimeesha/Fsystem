package com.example.smartassistantapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ExpenseAdapter(
    private val expenseList: ArrayList<ExpenseModel>,
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    interface OnItemClickListener {
        fun onItemClick(expense: ExpenseModel)
    }

    inner class ExpenseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.expenseName)
        val category: TextView = itemView.findViewById(R.id.expenseCategory)
        val amount: TextView = itemView.findViewById(R.id.expenseAmount)
        val date: TextView = itemView.findViewById(R.id.expenseDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.expense_item_card, parent, false)
        return ExpenseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expenseList[position]
        holder.name.text = expense.name
        holder.category.text = expense.category
        holder.amount.text = "RM %.2f".format(expense.amount)
        holder.date.text = expense.date

        holder.itemView.setOnClickListener { listener.onItemClick(expense) }
    }

    override fun getItemCount(): Int = expenseList.size
}
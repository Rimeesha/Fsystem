package com.example.smartassistantapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class CreateEventActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_event)

        val titleInput = findViewById<EditText>(R.id.titleInput)
        val locationInput = findViewById<EditText>(R.id.locationInput)
        val descInput = findViewById<EditText>(R.id.descInput)

        val dateText = findViewById<TextView>(R.id.dateText)
        val timeText = findViewById<TextView>(R.id.timeText)
        val saveBtn = findViewById<Button>(R.id.saveBtn)

        var selectedDate = ""
        var selectedTime = ""

        // ⭐ Date Picker
        dateText.setOnClickListener {

            val cal = Calendar.getInstance()

            DatePickerDialog(this,
                { _, y, m, d ->
                    selectedDate = "$d/${m+1}/$y"
                    dateText.text = selectedDate
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        // ⭐ Time Picker
        timeText.setOnClickListener {

            val cal = Calendar.getInstance()

            TimePickerDialog(this,
                { _, h, min ->
                    selectedTime = "$h:$min"
                    timeText.text = selectedTime
                },
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                true
            ).show()
        }

        // ⭐ Save Event
        saveBtn.setOnClickListener {

            Toast.makeText(
                this,
                "Event Saved:\n${titleInput.text}",
                Toast.LENGTH_LONG
            ).show()

            finish()
        }
    }
}
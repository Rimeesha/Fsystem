package com.example.smartassistantapplication

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddActivityActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_activity)

        val etActivityName = findViewById<EditText>(R.id.etActivityName)
        val etDuration = findViewById<EditText>(R.id.etDuration)
        val tvCalories = findViewById<TextView>(R.id.tvCalories)
        val spinnerType = findViewById<Spinner>(R.id.spinnerType)
        val spinnerIntensity = findViewById<Spinner>(R.id.spinnerIntensity)

        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnCancel = findViewById<Button>(R.id.btnCancel)

        val editMode = intent.getBooleanExtra("editMode", false)
        val editId = intent.getIntExtra("id", 0)
        val editPosition = intent.getIntExtra("position", -1)

        if (editMode) {
            etActivityName.setText(intent.getStringExtra("activityName"))
            etDuration.setText(intent.getIntExtra("duration", 0).toString())
            tvCalories.text = "🔥 Calories: ${intent.getIntExtra("calories", 0)} kcal"
        }

        val types = listOf("Run", "Walk", "Gym", "Yoga", "Cycling")
        val intensity = listOf("Low", "Medium", "High")

        spinnerType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        spinnerIntensity.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intensity)

        fun calc() {
            val d = etDuration.text.toString().toIntOrNull() ?: 0
            val met = 7.0
            val cal = (met * d).toInt()
            tvCalories.text = "🔥 Calories: $cal kcal"
        }

        etDuration.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = calc()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnSave.setOnClickListener {

            val intent = Intent()
            intent.putExtra("activityName", etActivityName.text.toString())
            intent.putExtra("duration", etDuration.text.toString().toIntOrNull() ?: 0)
            intent.putExtra("calories", tvCalories.text.toString().replace("[^0-9]".toRegex(), "").toIntOrNull() ?: 0)

            intent.putExtra("id", editId)
            intent.putExtra("position", editPosition)

            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        btnCancel.setOnClickListener { finish() }
    }
}
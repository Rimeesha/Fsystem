package com.example.smartassistantapplication

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import java.util.*

class AddTaskActivity : AppCompatActivity() {

    lateinit var db: TaskDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)

        db = TaskDatabaseHelper(this)

        val title = findViewById<EditText>(R.id.taskTitle)
        val date = findViewById<EditText>(R.id.taskDate)
        val time = findViewById<EditText>(R.id.taskTime)
        val desc = findViewById<EditText>(R.id.taskDescription)
        val saveBtn = findViewById<Button>(R.id.saveTaskBtn)

        val topBar = findViewById<MaterialToolbar>(R.id.topBar)

        // ===== TOP BAR BACK =====
        topBar.setNavigationOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
            finish()
        }

        // ===== DATE PICKER =====
        date.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    date.setText("$d/${m + 1}/$y")
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        // ===== TIME PICKER =====
        time.setOnClickListener {
            val calendar = Calendar.getInstance()
            TimePickerDialog(
                this,
                { _, h, m ->
                    time.setText(String.format("%02d:%02d", h, m))
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
            ).show()
        }

        // ===== SAVE TASK =====
        saveBtn.setOnClickListener {
            if (title.text.isEmpty() || date.text.isEmpty() || time.text.isEmpty()) {
                Toast.makeText(this, "Please fill in required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val task = Task(
                title = title.text.toString(),
                description = desc.text.toString(),
                date = date.text.toString(),
                time = time.text.toString()
            )

            val result = db.addTask(task)

            if (result > 0) {
                Toast.makeText(this, "Task Saved", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, CalendarActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Error saving task", Toast.LENGTH_SHORT).show()
            }
        }

        // ===== BOTTOM MENU (TEXT ONLY) =====
        setupBottomMenu()
        highlightSelected(R.id.nav_task)
    }

    private fun setupBottomMenu() {

        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            highlightSelected(R.id.nav_home)
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_task).setOnClickListener {
            highlightSelected(R.id.nav_task)
        }

        findViewById<TextView>(R.id.nav_grocery).setOnClickListener {
            highlightSelected(R.id.nav_grocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_bill).setOnClickListener {
            highlightSelected(R.id.nav_bill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_meal).setOnClickListener {
            highlightSelected(R.id.nav_meal)
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_health).setOnClickListener {
            highlightSelected(R.id.nav_health)
            startActivity(Intent(this, HealthActivity::class.java))
        }
    }

    private fun highlightSelected(selectedId: Int) {

        val items = listOf(
            findViewById<TextView>(R.id.nav_home),
            findViewById<TextView>(R.id.nav_task),
            findViewById<TextView>(R.id.nav_grocery),
            findViewById<TextView>(R.id.nav_bill),
            findViewById<TextView>(R.id.nav_meal),
            findViewById<TextView>(R.id.nav_health)
        )

        val selectedBg = Color.parseColor("#2196F3")
        val defaultBg = Color.TRANSPARENT

        for (item in items) {
            item.setBackgroundColor(defaultBg)
            item.setTextColor(Color.WHITE)
        }

        val selectedView = when (selectedId) {
            R.id.nav_home -> items[0]
            R.id.nav_task -> items[1]
            R.id.nav_grocery -> items[2]
            R.id.nav_bill -> items[3]
            R.id.nav_meal -> items[4]
            R.id.nav_health -> items[5]
            else -> items[1]
        }

        selectedView.setBackgroundColor(selectedBg)
        selectedView.setTextColor(Color.BLACK)
    }
}
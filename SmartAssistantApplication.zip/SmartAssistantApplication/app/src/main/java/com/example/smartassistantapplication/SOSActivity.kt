package com.example.smartassistantapplication

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SOSActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private val contactList = mutableListOf<Contact>()
    private lateinit var adapter: ContactAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sos)

        val etName = findViewById<EditText>(R.id.etName)
        val etPhone = findViewById<EditText>(R.id.etPhone)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSendAll = findViewById<Button>(R.id.btnSendAll)
        val btnPanic = findViewById<Button>(R.id.btnPanic)
        val btnHome = findViewById<Button>(R.id.btnHome)

        recycler = findViewById(R.id.recyclerContacts)

        loadContacts()

        adapter = ContactAdapter(contactList) { position ->
            deleteContact(position)
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        // ADD CONTACT
        btnAdd.setOnClickListener {

            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()

            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Enter details", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            contactList.add(Contact(name, phone))
            saveContacts()

            adapter.notifyDataSetChanged()

            etName.text.clear()
            etPhone.text.clear()
        }

        // SOS
        btnSendAll.setOnClickListener {
            sendSMSAll("🚨 SOS ALERT!")
        }

        // PANIC
        btnPanic.setOnClickListener {
            val location = getLocation()
            sendSMSAll("🚨 PANIC ALERT!\n$location")

            if (contactList.isNotEmpty()) {
                val first = contactList[0].phone

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$first")))
                }
            }
        }

        // HOME
        btnHome.setOnClickListener {
            finish()
        }
    }

    // SAVE
    private fun saveContacts() {
        val prefs = getSharedPreferences("SOS", MODE_PRIVATE)

        val set = contactList.map {
            "${it.name}|${it.phone}"
        }.toSet()

        prefs.edit().putStringSet("contacts", set).apply()
    }

    // LOAD
    private fun loadContacts() {
        val prefs = getSharedPreferences("SOS", MODE_PRIVATE)
        val set = prefs.getStringSet("contacts", emptySet())

        contactList.clear()

        set?.forEach {
            val parts = it.split("|")
            if (parts.size == 2) {
                contactList.add(Contact(parts[0], parts[1]))
            }
        }
    }

    // DELETE
    private fun deleteContact(position: Int) {
        contactList.removeAt(position)
        saveContacts()
        adapter.notifyDataSetChanged()
    }

    // SMS ALL
    private fun sendSMSAll(message: String) {

        val prefs = getSharedPreferences("SOS", MODE_PRIVATE)
        val set = prefs.getStringSet("contacts", emptySet())

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val sms = SmsManager.getDefault()

        set?.forEach {
            val phone = it.split("|")[1]
            sms.sendTextMessage(phone, null, message, null, null)
        }

        Toast.makeText(this, "Sent", Toast.LENGTH_SHORT).show()
    }

    // LOCATION
    private fun getLocation(): String {

        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        return try {
            val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)

            if (loc != null) {
                "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
            } else {
                "Location not found"
            }

        } catch (e: Exception) {
            "Error"
        }
    }
}
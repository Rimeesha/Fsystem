package com.example.smartassistantapplication

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ChangePasswordActivity : AppCompatActivity() {

    lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        dbHelper = DatabaseHelper(this)

        val oldPass = findViewById<EditText>(R.id.oldPassword)
        val newPass = findViewById<EditText>(R.id.newPassword)
        val confirmPass = findViewById<EditText>(R.id.confirmPassword)
        val changeButton = findViewById<Button>(R.id.changeButton)

        // Eye-toggle for all password fields
        setupPasswordToggle(oldPass)
        setupPasswordToggle(newPass)
        setupPasswordToggle(confirmPass)

        val prefs = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
        val email = prefs.getString("USERNAME", "") ?: ""

        changeButton.setOnClickListener {
            val oldText = oldPass.text.toString()
            val newText = newPass.text.toString()
            val confirmText = confirmPass.text.toString()

            if (oldText.isEmpty() || newText.isEmpty() || confirmText.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!dbHelper.checkUser(email, oldText)) {
                Toast.makeText(this, "Old password is incorrect", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (newText != confirmText) {
                Toast.makeText(this, "New passwords do not match", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val updated = dbHelper.updatePassword(email, newText)
            if (updated) {
                Toast.makeText(this, "Password changed successfully", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Failed to change password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Eye-toggle function for show/hide password */
    private fun setupPasswordToggle(editText: EditText) {
        editText.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val drawableEnd = 2 // Right drawable
                val drawable = editText.compoundDrawables[drawableEnd]
                if (drawable != null) {
                    if (event.rawX >= (editText.right - drawable.bounds.width() - editText.paddingEnd)) {
                        if (editText.inputType == (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                            // Show password
                            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                            editText.setCompoundDrawablesWithIntrinsicBounds(
                                editText.compoundDrawables[0],
                                editText.compoundDrawables[1],
                                resources.getDrawable(R.drawable.ic_eye_open, null),
                                editText.compoundDrawables[3]
                            )
                        } else {
                            // Hide password
                            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            editText.setCompoundDrawablesWithIntrinsicBounds(
                                editText.compoundDrawables[0],
                                editText.compoundDrawables[1],
                                resources.getDrawable(R.drawable.ic_eye_closed, null),
                                editText.compoundDrawables[3]
                            )
                        }
                        editText.setSelection(editText.text.length)
                        return@setOnTouchListener true
                    }
                }
            }
            false
        }
    }
}
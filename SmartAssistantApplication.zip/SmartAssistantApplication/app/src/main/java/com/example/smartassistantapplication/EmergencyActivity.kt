package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.bottomnavigation.BottomNavigationView

class EmergencyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_emergency)

        // CARDS
        val sosCard = findViewById<CardView>(R.id.cardSOS)
        val locationCard = findViewById<CardView>(R.id.cardLocation)
        val tipsCard = findViewById<CardView>(R.id.cardTips)

        // OPEN SOS PAGE
        sosCard.setOnClickListener {
            startActivity(Intent(this, SOSActivity::class.java))
        }

        // OPEN LOCATION PAGE
        locationCard.setOnClickListener {
            startActivity(Intent(this, ShareLocationActivity::class.java))
        }

        // OPEN SAFETY TIPS PAGE
        tipsCard.setOnClickListener {
            startActivity(Intent(this, SafetyTipsActivity::class.java))
        }

        // BOTTOM NAVIGATION
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)

        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->

            when(item.itemId){

                R.id.nav_home -> {
                    startActivity(Intent(this, DashboardActivity::class.java))
                    true
                }

                R.id.nav_tasks -> {
                    startActivity(Intent(this, CalendarActivity::class.java))
                    true
                }

                R.id.nav_grocery -> {
                    startActivity(Intent(this, GroceryActivity::class.java))
                    true
                }

                R.id.nav_bills -> {
                    startActivity(Intent(this, BillsExpensesActivity::class.java))
                    true
                }

                R.id.nav_meals -> {
                    startActivity(Intent(this, MealPlannerActivity::class.java))
                    true
                }

                R.id.nav_health -> {
                    startActivity(Intent(this, HealthActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }
}
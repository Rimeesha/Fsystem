package com.example.smartassistantapplication

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.appbar.MaterialToolbar

class CalendarActivity : AppCompatActivity() {

    private lateinit var calendarView: CalendarView
    private lateinit var taskRecycler: RecyclerView
    private lateinit var addBtn: FloatingActionButton
    private lateinit var topBar: MaterialToolbar

    private lateinit var taskAdapter: TaskAdapter
    private var taskList = ArrayList<Task>()
    private lateinit var db: TaskDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)

        calendarView = findViewById(R.id.monthCalendar)
        taskRecycler = findViewById(R.id.taskRecycler)
        addBtn = findViewById(R.id.addTaskBtn)
        topBar = findViewById(R.id.topToolbar)
        db = TaskDatabaseHelper(this)

        taskRecycler.layoutManager = LinearLayoutManager(this)

        // =========================
        // FIXED ADAPTER (DELETE + EDIT)
        // =========================
        taskAdapter = TaskAdapter(taskList,
            onDelete = { task ->
                db.deleteTask(task.id)
                taskList.remove(task)
                taskAdapter.notifyDataSetChanged()
            },
            onEdit = { task ->
                val intent = Intent(this, AddTaskActivity::class.java)
                intent.putExtra("EDIT_ID", task.id)
                intent.putExtra("EDIT_TITLE", task.title)
                intent.putExtra("EDIT_DESC", task.description)
                intent.putExtra("EDIT_DATE", task.date)
                intent.putExtra("EDIT_TIME", task.time)
                startActivity(intent)
            }
        )
        taskRecycler.adapter = taskAdapter

        loadTasks()

        // ADD TASK
        addBtn.setOnClickListener {
            startActivity(Intent(this, AddTaskActivity::class.java))
        }

        // CALENDAR CLICK
        calendarView.setOnDateChangeListener { _, year, month, day ->
            val selectedDate = "$day/${month + 1}/$year"
            Toast.makeText(this, selectedDate, Toast.LENGTH_SHORT).show()
        }

        // BACK BUTTON
        topBar.setNavigationOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }

        // DEFAULT HIGHLIGHT
        highlightSelected(R.id.nav_task)

        // NAVIGATION
        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            highlightSelected(R.id.nav_home)
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_task).setOnClickListener {
            highlightSelected(R.id.nav_task)
        }

        findViewById<TextView>(R.id.nav_grocery).setOnClickListener {
            highlightSelected(R.id.nav_grocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_bill).setOnClickListener {
            highlightSelected(R.id.nav_bill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_meal).setOnClickListener {
            highlightSelected(R.id.nav_meal)
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }


    }

    private fun highlightSelected(selectedId: Int) {

        val items = listOf(
            findViewById<TextView>(R.id.nav_home),
            findViewById<TextView>(R.id.nav_task),
            findViewById<TextView>(R.id.nav_grocery),
            findViewById<TextView>(R.id.nav_bill),
            findViewById<TextView>(R.id.nav_meal)
        )

        val selectedBg = Color.parseColor("#2196F3")
        val defaultBg = Color.TRANSPARENT

        for (item in items) {
            item.setBackgroundColor(defaultBg)
            item.setTextColor(Color.WHITE)
        }

        val selectedView = when (selectedId) {
            R.id.nav_home -> items[0]
            R.id.nav_task -> items[1]
            R.id.nav_grocery -> items[2]
            R.id.nav_bill -> items[3]
            R.id.nav_meal -> items[4]
            else -> items[1]
        }

        selectedView.setBackgroundColor(selectedBg)
        selectedView.setTextColor(Color.BLACK)
    }

    private fun loadTasks() {
        taskList.clear()
        taskList.addAll(db.getAllTasks())
        taskAdapter.notifyDataSetChanged()
    }
}
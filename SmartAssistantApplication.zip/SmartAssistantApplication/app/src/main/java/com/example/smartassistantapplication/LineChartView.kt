package com.example.smartassistantapplication

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class LineChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values = listOf(3f, 4f, 2f, 5f, 4f, 3f, 4f)

    private val linePaint = Paint().apply {
        color = Color.parseColor("#3F51B5")
        strokeWidth = 6f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val pointPaint = Paint().apply {
        color = Color.parseColor("#FF4081")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.DKGRAY
        textSize = 24f
        textAlign = Paint.Align.CENTER
    }

    fun setData(data: List<Float>) {
        values = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (values.size < 2) return

        val w = width.toFloat()
        val h = height.toFloat()

        val maxVal = values.maxOrNull() ?: 1f
        val stepX = w / (values.size - 1)

        var prevX = 0f
        var prevY = 0f

        values.forEachIndexed { i, v ->

            val x = i * stepX
            val y = h - (v / maxVal * h * 0.8f)

            if (i > 0) {
                canvas.drawLine(prevX, prevY, x, y, linePaint)
            }

            canvas.drawCircle(x, y, 8f, pointPaint)

            prevX = x
            prevY = y
        }

        canvas.drawText("Mood Trend", w / 2, 30f, textPaint)
    }
}
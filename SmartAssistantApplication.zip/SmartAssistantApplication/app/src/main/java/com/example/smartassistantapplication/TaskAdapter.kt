package com.example.smartassistantapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(
    private val tasks: ArrayList<Task>,
    private val onDelete: (Task) -> Unit,
    private val onEdit: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val title: TextView = view.findViewById(R.id.taskTitle)
        val description: TextView = view.findViewById(R.id.taskDescription)
        val dateTime: TextView = view.findViewById(R.id.taskDateTime)

        // these are now LinearLayout (icon + text row)
        val btnDelete: LinearLayout = view.findViewById(R.id.btnDeleteTask)
        val btnEdit: LinearLayout = view.findViewById(R.id.btnEditTask)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task_card, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = tasks.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val task = tasks[position]

        holder.title.text = task.title
        holder.description.text = task.description
        holder.dateTime.text = "${task.date} ${task.time}"

        // DELETE
        holder.btnDelete.setOnClickListener {
            onDelete(task)
        }

        // EDIT
        holder.btnEdit.setOnClickListener {
            onEdit(task)
        }
    }
}
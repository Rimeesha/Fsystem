package com.example.smartassistantapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.bottomnavigation.BottomNavigationView

class HelplineActivity : AppCompatActivity() {

    private val CALL_PERMISSION_REQUEST = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_helpline)

        // ==========================
        // HELPLINE CARDS
        // ==========================
        val ambulanceCard = findViewById<MaterialCardView>(R.id.cardAmbulance)
        val policeCard = findViewById<MaterialCardView>(R.id.cardPolice)
        val medicalCard = findViewById<MaterialCardView>(R.id.cardMedical)
        val fireCard = findViewById<MaterialCardView>(R.id.cardFire)

        ambulanceCard.setOnClickListener { makeCall("999") }
        policeCard.setOnClickListener { makeCall("999") }
        medicalCard.setOnClickListener { makeCall("999") }
        fireCard.setOnClickListener { makeCall("994") }

        // ==========================
        // BOTTOM NAVIGATION
        // ==========================
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }

                R.id.nav_tasks -> {
                    startActivity(Intent(this, CalendarActivity::class.java))
                    true
                }

                R.id.nav_grocery -> {
                    startActivity(Intent(this, GroceryActivity::class.java))
                    true
                }

                R.id.nav_bills -> {
                    startActivity(Intent(this, BillsExpensesActivity::class.java))
                    true
                }

                R.id.nav_meals -> {
                    startActivity(Intent(this, MealPlannerActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }

    // ✅ THIS FUNCTION WAS MISSING (CAUSE OF YOUR ERROR)
    private fun makeCall(number: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CALL_PHONE),
                CALL_PERMISSION_REQUEST
            )

        } else {
            val intent = Intent(Intent.ACTION_CALL)
            intent.data = Uri.parse("tel:$number")
            startActivity(intent)
        }
    }

    // Permission result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == CALL_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted, tap again", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
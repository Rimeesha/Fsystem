package com.example.smartassistantapplication

data class ProductModel(
    val name: String,
    val price: String,
    val image: Int,
    val desc: String,
    val rating: String,
    val category: String? = "Grocery"
)
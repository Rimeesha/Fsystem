package com.example.smartassistantapplication

data class Task(
    var id: Int = 0,
    var title: String,
    var description: String,
    var date: String,
    var time: String
)
package com.example.smartassistantapplication

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import android.app.AlertDialog   // ✅ FIXED HERE

class ProductAdapter(
    private val context: Context,
    private var productList: ArrayList<ProductModel>
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    private val childPin = "1234"

    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val productImage: ImageView = view.findViewById(R.id.productImage)
        val productName: TextView = view.findViewById(R.id.productName)
        val productPrice: TextView = view.findViewById(R.id.productPrice)
        val btnAddCart: Button = view.findViewById(R.id.btnAddCart)
        val btnBuyNow: Button = view.findViewById(R.id.btnBuyNow)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun getItemCount(): Int = productList.size

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {

        val product = productList[position]

        holder.productName.text = product.name
        holder.productPrice.text = product.price
        holder.productImage.setImageResource(product.image)

        val mainColor = ColorStateList.valueOf(Color.parseColor("#682366"))

        holder.btnAddCart.backgroundTintList = mainColor
        holder.btnBuyNow.backgroundTintList = mainColor

        // =========================
        // 🛒 ADD TO CART (PIN CHECK)
        // =========================
        holder.btnAddCart.setOnClickListener {

            val cleanPrice = product.price.replace("RM", "").toDouble()

            if (product.category == "Toy") {

                val pinInput = EditText(context)
                pinInput.hint = "Enter PIN"
                pinInput.inputType =
                    android.text.InputType.TYPE_CLASS_NUMBER or
                            android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD

                AlertDialog.Builder(context)
                    .setTitle("Child Product Locked")
                    .setMessage("Enter PIN to add this item")
                    .setView(pinInput)
                    .setPositiveButton("Confirm") { dialog, _ ->

                        if (pinInput.text.toString() == childPin) {

                            val db = CartDatabaseHelper(context)
                            db.addCart(product.name, cleanPrice, product.image)

                            Toast.makeText(context, "Added to Cart", Toast.LENGTH_SHORT).show()

                            val intent = Intent(context, CartNewPageActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            context.startActivity(intent)

                        } else {
                            Toast.makeText(context, "Wrong PIN!", Toast.LENGTH_SHORT).show()
                        }

                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()

            } else {

                val db = CartDatabaseHelper(context)
                db.addCart(product.name, cleanPrice, product.image)

                Toast.makeText(context, "Added to Cart", Toast.LENGTH_SHORT).show()

                val intent = Intent(context, CartNewPageActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
            }
        }

        // =========================
        // BUY NOW
        // =========================
        holder.btnBuyNow.setOnClickListener {
            val intent = Intent(context, ProductDetailActivity::class.java)
            intent.putExtra("name", product.name)
            intent.putExtra("price", product.price)
            intent.putExtra("desc", product.desc)
            intent.putExtra("rating", product.rating)
            intent.putExtra("image", product.image)
            intent.putExtra("category", product.category)
            context.startActivity(intent)
        }
    }

    // =========================
    // SEARCH FILTER
    // =========================
    fun filterList(filteredList: ArrayList<ProductModel>) {
        productList = filteredList
        notifyDataSetChanged()
    }
}
package com.example.smartassistantapplication

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class HealthActivity : AppCompatActivity() {

    private var waterCount = 0
    private val waterGoal = 8
    private lateinit var dbHelper: ActivityDatabaseHelper

    private lateinit var activitiesList: MutableList<ActivityItem>
    private lateinit var adapter: ActivityAdapter

    private lateinit var tvWaterCircle: TextView
    private lateinit var pbWaterCircular: ProgressBar
    private lateinit var tvBMIResult: TextView

    private lateinit var today: String

    companion object {
        const val REQUEST_CODE_ADD_ACTIVITY = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_health)

        dbHelper = ActivityDatabaseHelper(this)
        today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        // ================= WATER =================
        tvWaterCircle = findViewById(R.id.tvWaterCircle)
        pbWaterCircular = findViewById(R.id.pbWaterCircular)

        val btnAddWater = findViewById<Button>(R.id.btnAddWater)
        val btnResetWater = findViewById<Button>(R.id.btnResetWater)

        waterCount = dbHelper.getWaterIntake(today)
        updateWaterUI()

        btnAddWater.setOnClickListener {
            if (waterCount < waterGoal) {
                waterCount++
                updateWaterUI()
                dbHelper.addOrUpdateWaterIntake(today, waterCount)
            }
        }

        btnResetWater.setOnClickListener {
            waterCount = 0
            updateWaterUI()
            dbHelper.addOrUpdateWaterIntake(today, waterCount)
        }

        // ================= BMI =================
        tvBMIResult = findViewById(R.id.tvBMIResult)
        val etHeight = findViewById<EditText>(R.id.etHeight)
        val etWeight = findViewById<EditText>(R.id.etWeight)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)

        btnCalculate.setOnClickListener {

            val h = etHeight.text.toString().toFloatOrNull()
            val w = etWeight.text.toString().toFloatOrNull()

            if (h == null || w == null) {
                Toast.makeText(this, "Enter valid data", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val bmi = w / ((h / 100) * (h / 100))

            val category = when {
                bmi < 18.5 -> "Underweight"
                bmi < 25 -> "Normal"
                bmi < 30 -> "Overweight"
                else -> "Obese"
            }

            AlertDialog.Builder(this)
                .setTitle("BMI Result")
                .setMessage("BMI: %.2f\nCategory: %s".format(bmi, category))
                .setPositiveButton("OK", null)
                .show()

            tvBMIResult.text = "BMI: %.2f (%s)".format(bmi, category)
            tvBMIResult.setBackgroundColor(Color.parseColor(getColor(category)))

            dbHelper.addOrUpdateBMI(today, bmi, category)
        }

        // ================= ACTIVITY LIST =================
        val rv = findViewById<RecyclerView>(R.id.rvActivities)
        val btnAdd = findViewById<Button>(R.id.btnAddActivity)

        activitiesList = dbHelper.getAllActivities().toMutableList()

        adapter = ActivityAdapter(
            activitiesList,
            onEdit = { position ->

                val item = activitiesList[position]

                val intent = Intent(this, AddActivityActivity::class.java)
                intent.putExtra("editMode", true)
                intent.putExtra("id", item.id)
                intent.putExtra("position", position)
                intent.putExtra("activityName", item.name)
                intent.putExtra("duration", item.duration)
                intent.putExtra("calories", item.calories)

                startActivityForResult(intent, REQUEST_CODE_ADD_ACTIVITY)
            },
            onDelete = { pos ->
                val item = activitiesList[pos]
                dbHelper.deleteActivity(item.id)
                activitiesList.removeAt(pos)
                adapter.notifyItemRemoved(pos)
            }
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        btnAdd.setOnClickListener {
            val intent = Intent(this, AddActivityActivity::class.java)
            startActivityForResult(intent, REQUEST_CODE_ADD_ACTIVITY)
        }

        setupBottomMenu()
    }

    // ================= RESULT =================
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_ADD_ACTIVITY && resultCode == RESULT_OK && data != null) {

            val id = data.getIntExtra("id", 0)
            val name = data.getStringExtra("activityName") ?: return
            val duration = data.getIntExtra("duration", 0)
            val calories = data.getIntExtra("calories", 0)
            val position = data.getIntExtra("position", -1)

            if (position != -1) {
                val updated = ActivityItem(id, name, duration, calories)
                dbHelper.updateActivity(updated)
                activitiesList[position] = updated
                adapter.notifyItemChanged(position)
            } else {
                val newId = dbHelper.addActivity(
                    ActivityItem(name = name, duration = duration, calories = calories)
                ).toInt()

                activitiesList.add(ActivityItem(newId, name, duration, calories))
                adapter.notifyItemInserted(activitiesList.size - 1)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        activitiesList.clear()
        activitiesList.addAll(dbHelper.getAllActivities())
        adapter.notifyDataSetChanged()
    }

    private fun updateWaterUI() {
        tvWaterCircle.text = "$waterCount / $waterGoal Glasses"
        pbWaterCircular.progress = (waterCount * 100) / waterGoal
    }

    private fun getColor(category: String): String {
        return when (category) {
            "Underweight" -> "#2196F3"
            "Normal" -> "#4CAF50"
            "Overweight" -> "#FF9800"
            else -> "#F44336"
        }
    }

    private fun setupBottomMenu() {

        val navHome = findViewById<TextView>(R.id.nav_home)
        val navTask = findViewById<TextView>(R.id.nav_task)
        val navGrocery = findViewById<TextView>(R.id.nav_grocery)
        val navBill = findViewById<TextView>(R.id.nav_bill)
        val navMeal = findViewById<TextView>(R.id.nav_meal)

        fun highlight(selected: TextView) {
            val items = listOf(navHome, navTask, navGrocery, navBill, navMeal)

            items.forEach {
                it.setBackgroundColor(Color.TRANSPARENT)
                it.setTextColor(Color.WHITE)
            }

            selected.setBackgroundColor(Color.parseColor("#2196F3"))
            selected.setTextColor(Color.parseColor("#682366"))
        }

        navHome.setOnClickListener {
            highlight(navHome)
            startActivity(Intent(this, HomeActivity::class.java))
        }

        navTask.setOnClickListener {
            highlight(navTask)
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        navGrocery.setOnClickListener {
            highlight(navGrocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        navBill.setOnClickListener {
            highlight(navBill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        navMeal.setOnClickListener {
            highlight(navMeal)
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }

        highlight(navHome)
    }
}
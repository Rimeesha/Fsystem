package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class CartDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "ShoppingCart.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "cart"
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_PRICE = "price"
        private const val COL_QTY = "qty"
        private const val COL_IMAGE = "image"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NAME TEXT,
                $COL_PRICE REAL,
                $COL_QTY INTEGER,
                $COL_IMAGE INTEGER
            )
        """.trimIndent()

        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // ===== ADD ITEM TO CART =====
    fun addCart(name: String, price: Double, image: Int, qty: Int = 1) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NAME, name)
            put(COL_PRICE, price)
            put(COL_QTY, qty)  // ✅ Make sure this matches column name
            put(COL_IMAGE, image)
        }
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    // ===== GET ALL CART ITEMS =====
    fun getAllCart(): ArrayList<CartItem> {
        val list = ArrayList<CartItem>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME", null)
        if (cursor.moveToFirst()) {
            do {
                val item = CartItem(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
                    price = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_PRICE)),
                    qty = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QTY)),
                    image = cursor.getInt(cursor.getColumnIndexOrThrow(COL_IMAGE)),
                    selected = true
                )
                list.add(item)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    // ===== UPDATE QUANTITY =====
    fun updateQty(id: Int, qty: Int) {
        val db = writableDatabase
        val values = ContentValues().apply { put(COL_QTY, qty) }
        db.update(TABLE_NAME, values, "$COL_ID=?", arrayOf(id.toString()))
        db.close()
    }

    // ===== DELETE ITEM =====
    fun deleteItem(id: Int) {
        val db = writableDatabase
        db.delete(TABLE_NAME, "$COL_ID=?", arrayOf(id.toString()))
        db.close()
    }

    // ===== CLEAR CART =====
    fun clearCart() {
        val db = writableDatabase
        db.delete(TABLE_NAME, null, null)
        db.close()
    }
}
package com.example.smartassistantapplication

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar

class GroceryActivity : AppCompatActivity() {

    lateinit var recyclerView: RecyclerView
    lateinit var topBar: MaterialToolbar
    lateinit var searchBar: EditText
    lateinit var productList: ArrayList<ProductModel>
    lateinit var adapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grocery)

        topBar = findViewById(R.id.topBar)
        recyclerView = findViewById(R.id.recyclerView)
        searchBar = findViewById(R.id.searchBar)

        // BACK BUTTON
        topBar.setNavigationOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }

        recyclerView.layoutManager = GridLayoutManager(this, 2)

        loadProducts()
        adapter = ProductAdapter(this, productList)
        recyclerView.adapter = adapter

        // SEARCH
        searchBar.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().lowercase()
                val filtered = productList.filter {
                    it.name.lowercase().contains(query)
                } as ArrayList<ProductModel>
                adapter.filterList(filtered)
            }
        })

        setupBottomMenu()
        highlightSelected(R.id.nav_grocery)
    }

    // ---------------- BOTTOM MENU ----------------
    private fun setupBottomMenu() {

        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            highlightSelected(R.id.nav_home)
            startActivity(Intent(this, HomeActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_task).setOnClickListener {
            highlightSelected(R.id.nav_task)
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_grocery).setOnClickListener {
            highlightSelected(R.id.nav_grocery)
        }

        findViewById<TextView>(R.id.nav_bill).setOnClickListener {
            highlightSelected(R.id.nav_bill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_meal).setOnClickListener {
            highlightSelected(R.id.nav_meal)
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }

    }

    // ---------------- HIGHLIGHT ----------------
    private fun highlightSelected(selectedId: Int) {

        val items = listOf(
            findViewById<TextView>(R.id.nav_home),
            findViewById<TextView>(R.id.nav_task),
            findViewById<TextView>(R.id.nav_grocery),
            findViewById<TextView>(R.id.nav_bill),
            findViewById<TextView>(R.id.nav_meal)
        )

        val selectedBg = Color.parseColor("#2196F3")
        val defaultBg = Color.TRANSPARENT

        for (item in items) {
            item.setBackgroundColor(defaultBg)
            item.setTextColor(Color.WHITE)
        }

        val selectedView = when (selectedId) {
            R.id.nav_home -> items[0]
            R.id.nav_task -> items[1]
            R.id.nav_grocery -> items[2]
            R.id.nav_bill -> items[3]
            R.id.nav_meal -> items[4]
            else -> items[2]
        }

        selectedView.setBackgroundColor(selectedBg)
        selectedView.setTextColor(Color.BLACK)
    }

    private fun loadProducts() {
        productList = arrayListOf(
            ProductModel("Milk", "RM5", R.drawable.milk, "Fresh milk", "4.5", "Grocery"),
            ProductModel("Bread", "RM3", R.drawable.bread, "Soft bread", "4.2", "Grocery"),
            ProductModel("Egg", "RM12", R.drawable.egg, "Farm eggs", "4.8", "Grocery"),
            ProductModel("Rice", "RM20", R.drawable.rice, "Premium rice", "4.6", "Grocery"),
            ProductModel("Apple", "RM8", R.drawable.apple, "Fresh apple", "4.7", "Grocery"),
            ProductModel("Fish", "RM15", R.drawable.fish, "Fresh fish", "4.5", "Grocery"),

            // NEW ITEMS
            ProductModel("Lego", "RM50", R.drawable.lego, "Kids building toy", "4.9", "Toy"),
            ProductModel("Pencil", "RM2", R.drawable.pencil, "HB pencil", "4.3", "Stationery")
        )
    }
}
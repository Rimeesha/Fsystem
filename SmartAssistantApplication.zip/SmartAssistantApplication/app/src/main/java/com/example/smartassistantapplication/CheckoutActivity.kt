package com.example.smartassistantapplication

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import java.text.SimpleDateFormat
import java.util.*

class CheckoutActivity : AppCompatActivity() {

    private val parentPin = "1234"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        val topBar = findViewById<MaterialToolbar>(R.id.topBar)

        val txtProductName = findViewById<TextView>(R.id.txtProductName)
        val txtQty = findViewById<TextView>(R.id.txtQty)
        val txtSubtotal = findViewById<TextView>(R.id.txtSubtotal)

        val txtSubtotal2 = findViewById<TextView>(R.id.txtSubtotal2)
        val txtDelivery = findViewById<TextView>(R.id.txtDelivery)
        val txtDiscount = findViewById<TextView>(R.id.txtDiscount)
        val txtTotal = findViewById<TextView>(R.id.txtTotal)
        val bottomTotal = findViewById<TextView>(R.id.bottomTotal)

        val edtName = findViewById<EditText>(R.id.edtName)
        val edtPhone = findViewById<EditText>(R.id.edtPhone)
        val edtAddress = findViewById<EditText>(R.id.edtAddress)
        val spinnerPayment = findViewById<Spinner>(R.id.spinnerPayment)

        val btnPlaceOrder = findViewById<Button>(R.id.btnPlaceOrder)

        val orderDb = OrderDatabaseHelper(this)

        val paymentList = arrayOf("Cash", "Card", "Online Banking")
        spinnerPayment.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            paymentList
        )

        // ✅ RECEIVE MULTIPLE ITEMS FROM CART
        val items = intent.getStringArrayListExtra("items")

        val name = items?.joinToString(", ") ?: "Product"
        val qty = intent.getIntExtra("qty", 1)
        val category = intent.getStringExtra("category") ?: "Grocery"
        val totalPrice = intent.getDoubleExtra("price", 0.0)

        val deliveryFee = 5.0
        val discount = 0.0
        val finalTotal = totalPrice + deliveryFee - discount

        // UI
        txtProductName.text = "🛒 $name"
        txtQty.text = "📦 Qty: $qty"
        txtSubtotal.text = "Subtotal: RM %.2f".format(totalPrice)

        txtSubtotal2.text = "Subtotal: RM %.2f".format(totalPrice)
        txtDelivery.text = "Delivery: RM %.2f".format(deliveryFee)
        txtDiscount.text = "Voucher: -RM %.2f".format(discount)

        txtTotal.text = "Total: RM %.2f".format(finalTotal)
        bottomTotal.text = "RM %.2f".format(finalTotal)

        topBar.setNavigationOnClickListener { finish() }

        btnPlaceOrder.setOnClickListener {

            val buyerName = edtName.text.toString()
            val phone = edtPhone.text.toString()
            val address = edtAddress.text.toString()
            val payment = spinnerPayment.selectedItem.toString()

            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            val date = sdf.format(Date())

            if (buyerName.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (category == "School" || category == "Play") {
                showPinDialog(name, finalTotal, qty, buyerName, phone, address, payment, date, orderDb)
            } else {
                saveOrder(name, finalTotal, qty, buyerName, phone, address, payment, date, orderDb)
            }
        }
    }

    private fun saveOrder(
        name: String,
        totalPrice: Double,
        qty: Int,
        buyerName: String,
        phone: String,
        address: String,
        payment: String,
        date: String,
        orderDb: OrderDatabaseHelper
    ) {

        orderDb.insertOrder(
            name,
            "RM %.2f".format(totalPrice),
            qty,
            buyerName,
            phone,
            address,
            payment,
            date
        )

        // CLEAR CART AFTER ORDER
        val cartDb = CartDatabaseHelper(this)
        cartDb.clearCart()

        Toast.makeText(this, "Order placed!", Toast.LENGTH_SHORT).show()

        startActivity(Intent(this, OrderHistoryActivity::class.java))
        finish()
    }

    private fun showPinDialog(
        name: String,
        totalPrice: Double,
        qty: Int,
        buyerName: String,
        phone: String,
        address: String,
        payment: String,
        date: String,
        orderDb: OrderDatabaseHelper
    ) {

        val pinInput = EditText(this)
        pinInput.inputType =
            android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD

        AlertDialog.Builder(this)
            .setTitle("Parent Approval Required")
            .setMessage("Enter PIN to approve")
            .setView(pinInput)
            .setPositiveButton("Approve") { dialog, _ ->
                if (pinInput.text.toString() == parentPin) {
                    saveOrder(name, totalPrice, qty, buyerName, phone, address, payment, date, orderDb)
                } else {
                    Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
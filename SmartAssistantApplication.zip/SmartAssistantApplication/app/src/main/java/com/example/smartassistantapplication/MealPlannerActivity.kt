package com.example.smartassistantapplication

import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class MealPlannerActivity : AppCompatActivity() {

    private lateinit var db: MealDatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MealAdapter
    private lateinit var tvTotalCalories: TextView
    private lateinit var btnAddMeal: Button
    private lateinit var btnSelectDate: Button

    private var meals = mutableListOf<Meal>()

    private var selectedDate =
        SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_planner)

        db = MealDatabaseHelper(this)

        recyclerView = findViewById(R.id.recyclerMeals)
        tvTotalCalories = findViewById(R.id.tvTotalCalories)
        btnAddMeal = findViewById(R.id.btnAddMeal)
        btnSelectDate = findViewById(R.id.btnSelectDate)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MealAdapter(meals, { editMeal(it) }, { deleteMeal(it) })
        recyclerView.adapter = adapter

        btnAddMeal.setOnClickListener {
            startActivity(
                Intent(this, AddMealActivity::class.java)
                    .putExtra("SELECTED_DATE", selectedDate)
            )
        }

        btnSelectDate.setOnClickListener { showDatePicker() }

        setupBottomMenu()
        loadMeals()
    }

    override fun onResume() {
        super.onResume()
        loadMeals()
    }

    // =========================
    // FULL BLUE HIGHLIGHT (FIXED)
    // =========================
    private fun highlightSelected(id: Int) {

        val items = listOf(
            findViewById<TextView>(R.id.nav_home),
            findViewById<TextView>(R.id.nav_task),
            findViewById<TextView>(R.id.nav_grocery),
            findViewById<TextView>(R.id.nav_bill),
            findViewById<TextView>(R.id.nav_meal)
        )

        for (item in items) {
            item.setBackgroundColor(Color.TRANSPARENT)
            item.setTextColor(Color.WHITE)
        }

        val selected = when (id) {
            R.id.nav_home -> items[0]
            R.id.nav_task -> items[1]
            R.id.nav_grocery -> items[2]
            R.id.nav_bill -> items[3]
            R.id.nav_meal -> items[4]
            else -> items[4]
        }

        selected.setBackgroundColor(Color.parseColor("#2196F3"))
        selected.setTextColor(Color.BLACK)
    }

    // =========================
    // BOTTOM MENU (LIKE BILL PAGE)
    // =========================
    private fun setupBottomMenu() {

        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            highlightSelected(R.id.nav_home)
            startActivity(Intent(this, HomeActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_task).setOnClickListener {
            highlightSelected(R.id.nav_task)
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_grocery).setOnClickListener {
            highlightSelected(R.id.nav_grocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_bill).setOnClickListener {
            highlightSelected(R.id.nav_bill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_meal).setOnClickListener {
            highlightSelected(R.id.nav_meal)
        }


        // default selected
        highlightSelected(R.id.nav_meal)
    }

    // =========================
    // LOAD MEALS
    // =========================
    private fun loadMeals() {

        meals.clear()

        val cursor = db.getMealsByDate(selectedDate)
        var total = 0

        if (cursor != null && cursor.moveToFirst()) {
            do {
                val meal = Meal(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    mealName = cursor.getString(cursor.getColumnIndexOrThrow("mealName")),
                    mealType = cursor.getString(cursor.getColumnIndexOrThrow("mealType")),
                    calories = cursor.getInt(cursor.getColumnIndexOrThrow("calories")),
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                )

                meals.add(meal)
                total += meal.calories

            } while (cursor.moveToNext())

            cursor.close()
        }

        adapter.notifyDataSetChanged()
        tvTotalCalories.text = "Total Calories: $total kcal"
    }

    private fun editMeal(meal: Meal) {
        startActivity(
            Intent(this, AddMealActivity::class.java)
                .putExtra("EDIT_ID", meal.id)
        )
    }

    private fun deleteMeal(meal: Meal) {
        db.deleteMeal(meal.id)
        loadMeals()
    }

    // =========================
    // DATE PICKER (FIXED IMPORT ISSUE)
    // =========================
    private fun showDatePicker() {

        val calendar = Calendar.getInstance()
        val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

        DatePickerDialog(
            this,
            { _, y, m, d ->
                calendar.set(y, m, d)
                selectedDate = sdf.format(calendar.time)
                loadMeals()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
}
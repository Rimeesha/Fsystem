package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DatabaseHelper(this)

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val signupText = findViewById<TextView>(R.id.signupText)
        val forgotPassword = findViewById<TextView>(R.id.forgotPassword)

        // ---------------- PASSWORD TOGGLE ----------------
        password.setOnTouchListener { _, event ->

            if (event.action == MotionEvent.ACTION_UP) {

                val drawableEnd = 2

                if (event.rawX >= (password.right - password.compoundDrawables[drawableEnd].bounds.width())) {

                    if (password.inputType ==
                        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    ) {

                        // HIDE PASSWORD
                        password.inputType =
                            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

                        password.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_eye_closed,
                            0
                        )

                    } else {

                        // SHOW PASSWORD
                        password.inputType =
                            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD

                        password.setCompoundDrawablesWithIntrinsicBounds(
                            0,
                            0,
                            R.drawable.ic_eye_open,
                            0
                        )
                    }

                    password.setSelection(password.text.length)
                    return@setOnTouchListener true
                }
            }

            false
        }

        // ---------------- LOGIN ----------------
        loginButton.setOnClickListener {

            val emailText = email.text.toString().trim()
            val passText = password.text.toString().trim()

            if (emailText.isEmpty() || passText.isEmpty()) {

                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()

            } else {

                val check = dbHelper.checkUser(emailText, passText)

                if (check) {

                    val prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
                    prefs.edit().putString("USER_EMAIL", emailText).apply()

                    val intent = Intent(this, HomeActivity::class.java)
                    intent.putExtra("email", emailText)

                    startActivity(intent)
                    finish()

                } else {

                    Toast.makeText(
                        this,
                        "Wrong email or password",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // ---------------- SIGNUP ----------------
        signupText.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        // ---------------- FORGOT PASSWORD ----------------
        forgotPassword.setOnClickListener {

            val dialogView = layoutInflater.inflate(R.layout.dialog_forgot_password, null)

            val emailInput = dialogView.findViewById<EditText>(R.id.forgotEmail)
            val newPassInput = dialogView.findViewById<EditText>(R.id.newPassword)

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Reset Password")
            builder.setView(dialogView)

            builder.setPositiveButton("Update") { _, _ ->

                val emailText = emailInput.text.toString().trim()
                val newPassword = newPassInput.text.toString().trim()

                if (emailText.isEmpty() || newPassword.isEmpty()) {

                    Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()

                } else {

                    val result = dbHelper.updatePassword(emailText, newPassword)

                    if (result) {

                        Toast.makeText(
                            this,
                            "Password updated successfully",
                            Toast.LENGTH_LONG
                        ).show()

                    } else {

                        Toast.makeText(
                            this,
                            "Email not found",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            builder.setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }

            builder.show()
        }
    }
}
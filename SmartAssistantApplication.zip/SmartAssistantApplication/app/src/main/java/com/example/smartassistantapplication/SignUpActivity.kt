package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignUpActivity : AppCompatActivity() {

    lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        dbHelper = DatabaseHelper(this)

        val fullName = findViewById<EditText>(R.id.fullName)
        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val confirmPassword = findViewById<EditText>(R.id.confirmPassword)

        val signupButton = findViewById<Button>(R.id.signupButton)
        val backToLogin = findViewById<TextView>(R.id.backToLogin)

        // Toggle password visibility helper
        fun togglePassword(editText: EditText) {
            editText.setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    val drawableEnd = 2
                    if (event.rawX >= (editText.right - editText.compoundDrawables[drawableEnd].bounds.width())) {
                        if (editText.inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                            editText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            editText.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_eye_closed, 0)
                        } else {
                            editText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                            editText.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_eye_open, 0)
                        }
                        editText.setSelection(editText.text.length)
                        return@setOnTouchListener true
                    }
                }
                false
            }
        }

        togglePassword(password)
        togglePassword(confirmPassword)

        signupButton.setOnClickListener {
            val nameText = fullName.text.toString()
            val emailText = email.text.toString()
            val passText = password.text.toString()
            val confirmText = confirmPassword.text.toString()

            if (nameText.isEmpty() || emailText.isEmpty() || passText.isEmpty() || confirmText.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
            } else if (passText != confirmText) {
                Toast.makeText(this, "Password does not match", Toast.LENGTH_SHORT).show()
            } else {
                val insert = dbHelper.insertUser(nameText, emailText, passText)
                if (insert) {
                    Toast.makeText(this, "Signup Success", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Email already exists", Toast.LENGTH_SHORT).show()
                }
            }
        }

        backToLogin.setOnClickListener {
            finish()
        }

        // ✅ ADD ONLY (UI improvements)
        fullName.requestFocus()

        signupButton.alpha = 0f
        signupButton.animate().alpha(1f).setDuration(800).start()
    }
}
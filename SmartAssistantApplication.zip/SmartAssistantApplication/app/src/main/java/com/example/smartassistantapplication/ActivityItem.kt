package com.example.smartassistantapplication

data class ActivityItem(
    val id: Int = 0,
    val name: String,
    val duration: Int,
    val calories: Int
)
package com.example.smartassistantapplication

data class OrderModel(
    val id:Int,
    val invoice:String,
    val productName:String,
    val price:String,
    val quantity:Int,
    val buyerName:String,
    val phone:String,
    val address:String,
    val payment:String,
    val date:String
)
package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.ScaleAnimation
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.appbar.MaterialToolbar

class DashboardActivity : AppCompatActivity() {

    private lateinit var userNameText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        userNameText = findViewById(R.id.userNameText)

        // Cards
        val cardTasks = findViewById<MaterialCardView>(R.id.cardTasks)
        val cardGrocery = findViewById<MaterialCardView>(R.id.cardGrocery)
        val cardHelpline = findViewById<MaterialCardView>(R.id.cardHelpline)
        val cardTerms = findViewById<MaterialCardView>(R.id.cardTerms)
        val cardEmergency = findViewById<MaterialCardView>(R.id.cardEmergency)

        setupCard(cardTasks) { startActivity(Intent(this, CalendarActivity::class.java)) }
        setupCard(cardGrocery) { startActivity(Intent(this, GroceryActivity::class.java)) }
        setupCard(cardHelpline) { startActivity(Intent(this, HelplineActivity::class.java)) }
        setupCard(cardTerms) { startActivity(Intent(this, TermsPolicyActivity::class.java)) }
        setupCard(cardEmergency) { startActivity(Intent(this, EmergencyActivity::class.java)) }

        // Toolbar
        val topBar = findViewById<MaterialToolbar>(R.id.topAppBar)
        topBar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.action_sos -> {
                    startActivity(Intent(this, EmergencyActivity::class.java))
                    true
                }
                else -> false
            }
        }

        // Header icons
        findViewById<View>(R.id.sosIcon).setOnClickListener {
            startActivity(Intent(this, EmergencyActivity::class.java))
        }

        findViewById<View>(R.id.settingsIcon).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Bottom Nav
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_tasks -> { startActivity(Intent(this, CalendarActivity::class.java)); true }
                R.id.nav_grocery -> { startActivity(Intent(this, GroceryActivity::class.java)); true }
                R.id.nav_bills -> { startActivity(Intent(this, BillsExpensesActivity::class.java)); true }
                R.id.nav_meals -> { startActivity(Intent(this, MealPlannerActivity::class.java)); true }
                R.id.nav_health -> { startActivity(Intent(this, HealthActivity::class.java)); true }
                else -> false
            }
        }
    }

    // 🔥 THIS FIXES YOUR NAME UPDATE
    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
        val username = prefs.getString("USERNAME", "User") ?: "User"
        userNameText.text = username
    }

    private fun setupCard(card: MaterialCardView, onClick: () -> Unit) {
        card.setOnTouchListener { v, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    val anim = ScaleAnimation(
                        1.0f, 0.95f, 1.0f, 0.95f,
                        ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF, 0.5f
                    )
                    anim.duration = 100
                    anim.fillAfter = true
                    v.startAnimation(anim)
                }
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> {
                    val anim = ScaleAnimation(
                        0.95f, 1.0f, 0.95f, 1.0f,
                        ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF, 0.5f
                    )
                    anim.duration = 100
                    anim.fillAfter = true
                    v.startAnimation(anim)
                }
            }
            false
        }

        card.setOnClickListener { onClick() }
    }
}
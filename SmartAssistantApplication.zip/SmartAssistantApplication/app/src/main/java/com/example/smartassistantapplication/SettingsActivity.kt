package com.example.smartassistantapplication

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class SettingsActivity : AppCompatActivity() {

    private lateinit var tvEditProfile: TextView
    private lateinit var tvChangePassword: TextView
    private lateinit var tvLogout: TextView
    private lateinit var switchTheme: Switch
    private lateinit var switchNotifications: Switch
    private lateinit var btnResetDefaults: Button
    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Bind Views
        tvEditProfile = findViewById(R.id.tvEditProfile)
        tvChangePassword = findViewById(R.id.tvChangePassword)
        tvLogout = findViewById(R.id.tvLogout)
        switchTheme = findViewById(R.id.switchTheme)
        switchNotifications = findViewById(R.id.switchNotifications)
        btnResetDefaults = findViewById(R.id.btnResetDefaults)
        toolbar = findViewById(R.id.settingsToolbar)

        // ==========================
        // TOP BAR (TITLE + COLOR)
        // ==========================
        toolbar.title = "Settings"
        toolbar.setBackgroundColor(Color.parseColor("#682366"))
        toolbar.setTitleTextColor(Color.WHITE)
        toolbar.setNavigationOnClickListener { finish() }

        // ==========================
        // Click Listeners
        // ==========================
        tvEditProfile.setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }

        tvChangePassword.setOnClickListener {
            startActivity(Intent(this, ChangePasswordActivity::class.java))
        }

        tvLogout.setOnClickListener {
            val prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
            prefs.edit().remove("USERNAME").apply()

            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // ==========================
        // Switch Logic
        // ==========================
        switchTheme.setOnCheckedChangeListener { _, _ -> }

        switchNotifications.setOnCheckedChangeListener { _, _ -> }

        // ==========================
        // Reset Button
        // ==========================
        btnResetDefaults.setOnClickListener {
            switchTheme.isChecked = false
            switchNotifications.isChecked = true
        }
    }
}
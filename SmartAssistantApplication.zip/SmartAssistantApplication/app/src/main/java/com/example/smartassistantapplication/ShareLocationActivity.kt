package com.example.smartassistantapplication

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class ShareLocationActivity : AppCompatActivity() {

    private var locationText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share_location)

        val btnGet = findViewById<Button>(R.id.btnGet)
        val btnCopy = findViewById<Button>(R.id.btnCopy)
        val btnSendSOS = findViewById<Button>(R.id.btnSendSOS)
        val btnHome = findViewById<Button>(R.id.btnHome)
        val tv = findViewById<TextView>(R.id.tvLocation)

        btnGet.setOnClickListener {
            locationText = getLocation()
            tv.text = locationText
        }

        btnCopy.setOnClickListener {
            if (locationText.isNotEmpty()) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Location", locationText)
                clipboard.setPrimaryClip(clip)

                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
        }

        btnSendSOS.setOnClickListener {
            sendToEmergencyContacts()
        }

        btnHome.setOnClickListener {
            finish() // back to Home
        }
    }

    // ---------------- LOCATION ----------------
    private fun getLocation(): String {

        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        return try {
            val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)

            if (loc != null) {

                val link = "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"

                """
                📍 LIVE LOCATION

                Latitude: ${loc.latitude}
                Longitude: ${loc.longitude}

                🌍 Google Maps:
                $link
                """.trimIndent()

            } else {
                "Location not available (Turn ON GPS)"
            }

        } catch (e: Exception) {
            "Error getting location"
        }
    }

    // ---------------- SEND TO SOS CONTACTS ----------------
    private fun sendToEmergencyContacts() {

        if (locationText.isEmpty()) {
            Toast.makeText(this, "Get location first", Toast.LENGTH_SHORT).show()
            return
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                1
            )
            return
        }

        // 🔥 IMPORTANT: READ FROM SHARED PREFERENCES (FROM SOS PAGE)
        val prefs = getSharedPreferences("SOS", MODE_PRIVATE)
        val contacts = prefs.getStringSet("contacts", emptySet())

        if (contacts.isNullOrEmpty()) {
            Toast.makeText(this, "No emergency contacts found", Toast.LENGTH_SHORT).show()
            return
        }

        val sms = SmsManager.getDefault()

        for (item in contacts) {
            val phone = item.split("|")[1] // format: name|phone

            sms.sendTextMessage(
                phone,
                null,
                "🚨 EMERGENCY LOCATION:\n$locationText",
                null,
                null
            )
        }

        Toast.makeText(this, "Sent to emergency contacts", Toast.LENGTH_LONG).show()
    }
}
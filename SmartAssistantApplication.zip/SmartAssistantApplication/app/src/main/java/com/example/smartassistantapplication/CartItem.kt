package com.example.smartassistantapplication

data class CartItem(
    val id: Int,
    val name: String,
    val price: Double,
    var qty: Int,
    val image: Int,
    var selected: Boolean = true
)
package com.example.smartassistantapplication

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class BarChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values = listOf(0f, 0f, 0f, 0f)
    private var labels = listOf("Tasks", "Grocery", "Expense", "BMI")

    private val barPaint = Paint().apply {
        color = Color.parseColor("#682366")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = Color.DKGRAY
        textSize = 26f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val gridPaint = Paint().apply {
        color = Color.LTGRAY
        strokeWidth = 2f
    }

    fun setData(values: List<Float>, labels: List<String>) {
        this.values = values
        this.labels = labels
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (values.isEmpty()) return

        val w = width.toFloat()
        val h = height.toFloat()

        val max = values.maxOrNull()?.takeIf { it > 0 } ?: 1f

        val chartHeight = h * 0.75f
        val barWidth = w / values.size * 0.6f

        // light grid line
        canvas.drawLine(0f, chartHeight, w, chartHeight, gridPaint)

        values.forEachIndexed { i, value ->

            val xCenter = (i + 0.5f) * (w / values.size)

            val barHeight = (value / max) * chartHeight
            val left = xCenter - barWidth / 2
            val right = xCenter + barWidth / 2
            val top = chartHeight - barHeight
            val bottom = chartHeight

            // bar
            canvas.drawRect(left, top, right, bottom, barPaint)

            // label
            canvas.drawText(labels[i], xCenter, h - 20, textPaint)

            // value
            canvas.drawText(value.toInt().toString(), xCenter, top - 10, textPaint)
        }
    }
}
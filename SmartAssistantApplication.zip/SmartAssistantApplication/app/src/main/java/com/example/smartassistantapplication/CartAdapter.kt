package com.example.smartassistantapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView

class CartAdapter(
    private val context: Context,
    private val cartList: ArrayList<CartItem>,
    private val onCartChange: () -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    private val db = CartDatabaseHelper(context)

    inner class CartViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val chkSelect: CheckBox = view.findViewById(R.id.chkSelect)
        val image: ImageView = view.findViewById(R.id.image)
        val name: TextView = view.findViewById(R.id.name)
        val price: TextView = view.findViewById(R.id.price)
        val qty: TextView = view.findViewById(R.id.qty)
        val btnPlus: Button = view.findViewById(R.id.btnPlus)
        val btnMinus: Button = view.findViewById(R.id.btnMinus)
        val btnDelete: Button = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(context)
            .inflate(R.layout.cart_item, parent, false)
        return CartViewHolder(view)
    }

    override fun getItemCount(): Int = cartList.size

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {

        val item = cartList[position]

        holder.name.text = item.name
        holder.price.text = "RM${item.price * item.qty}"
        holder.qty.text = item.qty.toString()
        holder.image.setImageResource(item.image)
        holder.chkSelect.isChecked = item.selected

        // CHECKBOX
        holder.chkSelect.setOnCheckedChangeListener { _, isChecked ->
            item.selected = isChecked
            onCartChange()
        }

        // PLUS
        holder.btnPlus.setOnClickListener {
            item.qty++
            db.updateQty(item.id, item.qty)
            notifyItemChanged(position)
            onCartChange()
        }

        // MINUS
        holder.btnMinus.setOnClickListener {
            if (item.qty > 1) {
                item.qty--
                db.updateQty(item.id, item.qty)
                notifyItemChanged(position)
                onCartChange()
            }
        }

        // DELETE
        holder.btnDelete.setOnClickListener {

            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {

                val deleteItem = cartList[pos]

                db.deleteItem(deleteItem.id)

                cartList.removeAt(pos)

                notifyItemRemoved(pos)
                notifyItemRangeChanged(pos, cartList.size)

                onCartChange()

                Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
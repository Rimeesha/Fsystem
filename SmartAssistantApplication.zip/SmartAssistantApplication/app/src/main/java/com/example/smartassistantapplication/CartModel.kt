package com.example.smartassistantapplication

data class CartModel(
    val name: String,
    val price: String,
    val image: Int,
    var quantity: Int = 1
)
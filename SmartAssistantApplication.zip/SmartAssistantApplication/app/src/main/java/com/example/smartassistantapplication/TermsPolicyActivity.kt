package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class TermsPolicyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms_policy)

        val termsText = findViewById<TextView>(R.id.termsText)

        // ==========================
        // FULL TERMS TEXT (YOUR CONTENT)
        // ==========================
        termsText.text = """
Welcome to Smart Assistant App. By using this application, you agree to the following terms and privacy policies.

1. Terms of Service
- Users must provide accurate personal information.
- The app is for personal domestic assistance only.
- Smart Assistant features are automated; we do not guarantee 100% accuracy.
- Users are responsible for tasks scheduled and any consequences of incorrect use.
- The app may include updates or new features without prior notice.

2. Privacy Policy
- We collect data such as task entries, schedules, and basic profile info.
- Data is used only to improve your app experience and for notifications/reminders.
- We do not share your personal data with third parties without your consent.
- Data is stored securely and can be deleted upon user request.

3. Liability
- The app is a tool to assist with domestic tasks. We are not liable for any accidents or damages resulting from app use.
- Users must use caution when performing tasks suggested or scheduled by the app.

4. Changes to Terms
- Terms and policies may be updated. Users will be notified in-app.
- Last updated: 7th March 2026.

5. Acceptance
- By continuing to use the app, you agree to these terms and privacy policies.
        """.trimIndent()



        // ==========================
        // BOTTOM NAVIGATION (FIXED)
        // ==========================
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)

        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    true
                }

                R.id.nav_tasks -> {
                    startActivity(Intent(this, CalendarActivity::class.java))
                    true
                }

                R.id.nav_grocery -> {
                    startActivity(Intent(this, GroceryActivity::class.java))
                    true
                }

                R.id.nav_bills -> {
                    startActivity(Intent(this, BillsExpensesActivity::class.java))
                    true
                }

                R.id.nav_meals -> {
                    startActivity(Intent(this, MealPlannerActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }
}
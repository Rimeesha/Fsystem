package com.example.smartassistantapplication

data class Meal(
    val id: Int,
    val mealName: String,
    val mealType: String,
    val calories: Int,
    val date: String
)
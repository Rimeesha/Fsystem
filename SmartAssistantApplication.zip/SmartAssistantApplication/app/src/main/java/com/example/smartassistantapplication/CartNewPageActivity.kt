package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar

class CartNewPageActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var tvTotal: TextView
    private lateinit var btnCheckout: Button
    private lateinit var topBar: MaterialToolbar

    private lateinit var cartList: ArrayList<CartItem>
    private lateinit var adapter: CartAdapter
    private lateinit var db: CartDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart_new_page)

        topBar = findViewById(R.id.topBar)
        recyclerView = findViewById(R.id.recyclerViewCart)
        tvTotal = findViewById(R.id.tvTotal)
        btnCheckout = findViewById(R.id.btnCheckout)

        // BACK BUTTON FUNCTION
        topBar.setNavigationOnClickListener {
            val intent = Intent(this, GroceryActivity::class.java)
            startActivity(intent)
            finish()
        }

        db = CartDatabaseHelper(this)
        cartList = db.getAllCart()

        adapter = CartAdapter(this, cartList) {
            updateTotal()
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        updateTotal()

        // CHECKOUT BUTTON
        btnCheckout.setOnClickListener {

            val selectedItems = ArrayList<String>()
            var totalQty = 0
            var totalPrice = 0.0

            for (item in cartList) {
                if (item.selected) {
                    selectedItems.add(item.name)
                    totalQty += item.qty
                    totalPrice += item.price * item.qty
                }
            }

            if (selectedItems.isEmpty()) {
                Toast.makeText(this, "Please select items", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val intent = Intent(this, CheckoutActivity::class.java)
            intent.putStringArrayListExtra("items", selectedItems)
            intent.putExtra("qty", totalQty)
            intent.putExtra("price", totalPrice)
            intent.putExtra("category", "Grocery")

            startActivity(intent)
        }
    }

    private fun updateTotal() {
        var total = 0.0

        for (item in cartList) {
            if (item.selected) {
                total += item.price * item.qty
            }
        }

        tvTotal.text = "Total: RM %.2f".format(total)
    }
}
package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ExpenseDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "ExpenseDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE expenses(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT," +
                    "category TEXT," +
                    "amount REAL," +
                    "date TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insertExpense(name: String, category: String, amount: Double, date: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("category", category)
        values.put("amount", amount)
        values.put("date", date)
        db.insert("expenses", null, values)
    }

    fun getAllExpenses(): ArrayList<ExpenseModel> {
        val expenseList = ArrayList<ExpenseModel>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM expenses", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(0)
                val name = cursor.getString(1)
                val category = cursor.getString(2)
                val amount = cursor.getDouble(3)
                val date = cursor.getString(4)
                expenseList.add(ExpenseModel(id, name, category, amount, date))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return expenseList
    }

    fun deleteExpense(id: Int) {
        val db = writableDatabase
        db.delete("expenses", "id=?", arrayOf(id.toString()))
    }

    fun updateExpense(id: Int, name: String, category: String, amount: Double, date: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("category", category)
        values.put("amount", amount)
        values.put("date", date)
        db.update("expenses", values, "id=?", arrayOf(id.toString()))
    }
}
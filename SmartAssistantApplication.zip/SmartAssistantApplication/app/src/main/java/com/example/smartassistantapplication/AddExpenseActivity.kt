package com.example.smartassistantapplication

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class AddExpenseActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var etAmount: EditText
    private lateinit var etDate: EditText
    private lateinit var btnSave: Button

    private lateinit var db: ExpenseDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        etName = findViewById(R.id.etName)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        etAmount = findViewById(R.id.etAmount)
        etDate = findViewById(R.id.etDate)
        btnSave = findViewById(R.id.btnSave)

        db = ExpenseDatabaseHelper(this)

        // AUTO DATE
        val today = Calendar.getInstance().time
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        etDate.setText(sdf.format(today))

        // CATEGORY
        val categories = arrayOf("Food", "House", "Transport", "Bills", "Others")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = adapter

        // SAVE
        btnSave.setOnClickListener {
            val name = etName.text.toString()
            val category = spinnerCategory.selectedItem.toString()
            val amountText = etAmount.text.toString()
            val date = etDate.text.toString()

            if (name.isEmpty() || amountText.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val amount = amountText.toDouble()

            db.insertExpense(name, category, amount, date)

            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()

            startActivity(Intent(this, BillsExpensesActivity::class.java))
            finish()
        }

        // DEFAULT SELECT
        highlight(R.id.nav_bill)
    }

    // =========================
    // BOTTOM NAV HIGHLIGHT
    // =========================
    private fun highlight(selectedId: Int) {

        val items = listOf(
            findViewById<TextView>(R.id.nav_home),
            findViewById<TextView>(R.id.nav_task),
            findViewById<TextView>(R.id.nav_grocery),
            findViewById<TextView>(R.id.nav_bill),
            findViewById<TextView>(R.id.nav_meal)
        )

        for (item in items) {
            item.setBackgroundColor(Color.TRANSPARENT)
            item.setTextColor(Color.WHITE)
        }

        val selected = findViewById<TextView>(selectedId)
        selected.setBackgroundColor(Color.parseColor("#2196F3"))
        selected.setTextColor(Color.BLACK)
    }

    override fun onResume() {
        super.onResume()

        highlight(R.id.nav_bill)

        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            highlight(R.id.nav_home)
            startActivity(Intent(this, HomeActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_task).setOnClickListener {
            highlight(R.id.nav_task)
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_grocery).setOnClickListener {
            highlight(R.id.nav_grocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_bill).setOnClickListener {
            highlight(R.id.nav_bill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_meal).setOnClickListener {
            highlight(R.id.nav_meal)
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }
    }
}
package com.example.smartassistantapplication

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.text.SimpleDateFormat
import java.util.*

class AddMealActivity : AppCompatActivity() {

    private lateinit var etMealName: EditText
    private lateinit var spinnerMealType: Spinner
    private lateinit var btnAddMeal: Button
    private lateinit var db: MealDatabaseHelper

    private var selectedDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_meal)

        etMealName = findViewById(R.id.etMealName)
        spinnerMealType = findViewById(R.id.spinnerMealType)
        btnAddMeal = findViewById(R.id.btnAddMeal)

        db = MealDatabaseHelper(this)

        selectedDate = intent.getStringExtra("SELECTED_DATE")

        val mealTypes = arrayOf("Breakfast", "Lunch", "Dinner", "Snack")
        spinnerMealType.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            mealTypes
        )

        btnAddMeal.setOnClickListener {

            val name = etMealName.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(this, "Enter meal name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val type = spinnerMealType.selectedItem.toString()
            val calories = 300

            val date = selectedDate ?: SimpleDateFormat(
                "dd-MM-yyyy",
                Locale.getDefault()
            ).format(Date())

            db.insertMeal(name, type, calories, date)

            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            finish()
        }

        setupBottomMenu()
    }

    // =========================
    // FULL BLUE HIGHLIGHT
    // =========================
    private fun highlight(id: Int) {

        val items = listOf(
            findViewById<TextView>(R.id.nav_home),
            findViewById<TextView>(R.id.nav_task),
            findViewById<TextView>(R.id.nav_grocery),
            findViewById<TextView>(R.id.nav_bill),
            findViewById<TextView>(R.id.nav_meal)
        )

        for (i in items) {
            i.setBackgroundColor(Color.TRANSPARENT)
            i.setTextColor(Color.WHITE)
        }

        val selected = when (id) {
            R.id.nav_home -> items[0]
            R.id.nav_task -> items[1]
            R.id.nav_grocery -> items[2]
            R.id.nav_bill -> items[3]
            R.id.nav_meal -> items[4]
            else -> items[4]
        }

        selected.setBackgroundColor(Color.parseColor("#2196F3"))
        selected.setTextColor(Color.BLACK)
    }

    // =========================
    // BOTTOM MENU (LIKE MEAL PAGE)
    // =========================
    private fun setupBottomMenu() {

        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            highlight(R.id.nav_home)
            startActivity(Intent(this, HomeActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_task).setOnClickListener {
            highlight(R.id.nav_task)
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_grocery).setOnClickListener {
            highlight(R.id.nav_grocery)
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_bill).setOnClickListener {
            highlight(R.id.nav_bill)
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.nav_meal).setOnClickListener {
            highlight(R.id.nav_meal)
        }

        highlight(R.id.nav_meal)
    }
}
package com.example.smartassistantapplication

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class EditProfileActivity : AppCompatActivity() {

    lateinit var dbHelper: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences
    private var email: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        dbHelper = DatabaseHelper(this)

        prefs = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
        email = prefs.getString("USERNAME", "") ?: ""

        val fullNameEdit = findViewById<EditText>(R.id.fullNameEdit)
        val updateBtn = findViewById<Button>(R.id.updateProfileBtn)
        val changeEmailBtn = findViewById<Button>(R.id.changeEmailBtn)

        // Load current name
        fullNameEdit.setText(dbHelper.getFullName(email))

        // ========================
        // CHANGE EMAIL POPUP
        // ========================
        changeEmailBtn.setOnClickListener {

            val dialogView = layoutInflater.inflate(R.layout.dialog_change_email, null)

            val currentEmail = dialogView.findViewById<EditText>(R.id.currentEmail)
            val newEmail = dialogView.findViewById<EditText>(R.id.newEmail)

            currentEmail.setText(email)

            AlertDialog.Builder(this)
                .setTitle("Change Email")
                .setView(dialogView)
                .setPositiveButton("Save") { _, _ ->

                    val newE = newEmail.text.toString().trim()

                    if (newE.isEmpty()) {
                        Toast.makeText(this, "Enter new email", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }

                    if (dbHelper.checkEmailExists(newE)) {
                        Toast.makeText(this, "Email already exists", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }

                    val updated = dbHelper.updateEmail(email, newE)

                    if (updated) {
                        prefs.edit().putString("USERNAME", newE).apply()
                        email = newE
                        Toast.makeText(this, "Email updated successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Failed to update email", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // ========================
        // UPDATE NAME ONLY
        // ========================
        updateBtn.setOnClickListener {

            val newFullName = fullNameEdit.text.toString().trim()

            if (newFullName.isEmpty()) {
                Toast.makeText(this, "Name cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val updated = dbHelper.updateProfile(email, newFullName)

            if (updated) {
                Toast.makeText(this, "Name updated successfully", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to update name", Toast.LENGTH_SHORT).show()
            }

            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }
    }
}
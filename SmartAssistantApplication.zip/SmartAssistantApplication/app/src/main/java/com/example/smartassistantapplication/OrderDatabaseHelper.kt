package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class OrderDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context,"order_db",null,3) {

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("""
            CREATE TABLE orders(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice TEXT,
                productName TEXT,
                price TEXT,
                quantity INTEGER,
                buyerName TEXT,
                phone TEXT,
                address TEXT,
                payment TEXT,
                orderDate TEXT
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS orders")
        onCreate(db)
    }

    fun insertOrder(
        productName:String,
        price:String,
        qty:Int,
        buyerName:String,
        phone:String,
        address:String,
        payment:String,
        date:String
    ):Boolean{
        val db = writableDatabase
        val values = ContentValues()

        val invoice = "INV" + System.currentTimeMillis().toString().takeLast(6)

        values.put("invoice", invoice)
        values.put("productName",productName)
        values.put("price",price)
        values.put("quantity",qty)
        values.put("buyerName",buyerName)
        values.put("phone",phone)
        values.put("address",address)
        values.put("payment",payment)
        values.put("orderDate",date)

        val result = db.insert("orders",null,values)
        db.close()
        return result != -1L
    }

    fun deleteOrder(id:Int):Boolean{
        val db = writableDatabase
        val result = db.delete("orders","id=?", arrayOf(id.toString()))
        db.close()
        return result > 0
    }

    fun getAllOrders():ArrayList<OrderModel>{
        val list = ArrayList<OrderModel>()
        val db = readableDatabase

        val cursor = db.rawQuery("SELECT * FROM orders ORDER BY id DESC", null)

        if(cursor.moveToFirst()){
            do{
                val order = OrderModel(
                    cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("invoice")),
                    cursor.getString(cursor.getColumnIndexOrThrow("productName")),
                    cursor.getString(cursor.getColumnIndexOrThrow("price")),
                    cursor.getInt(cursor.getColumnIndexOrThrow("quantity")),
                    cursor.getString(cursor.getColumnIndexOrThrow("buyerName")),
                    cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                    cursor.getString(cursor.getColumnIndexOrThrow("address")),
                    cursor.getString(cursor.getColumnIndexOrThrow("payment")),
                    cursor.getString(cursor.getColumnIndexOrThrow("orderDate"))
                )
                list.add(order)
            }while(cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return list
    }
}
package com.example.smartassistantapplication

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity() {

    lateinit var taskDb: TaskDatabaseHelper
    lateinit var groceryDb: GroceryDatabaseHelper
    lateinit var expenseDb: ExpenseDatabaseHelper
    lateinit var healthDb: ActivityDatabaseHelper

    lateinit var txtTaskCount: TextView
    lateinit var txtGrocery: TextView
    lateinit var txtExpense: TextView
    lateinit var txtHealth: TextView
    lateinit var txtInsight: TextView

    lateinit var barChart: BarChartView
    lateinit var lineChart: LineChartView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // DB
        taskDb = TaskDatabaseHelper(this)
        groceryDb = GroceryDatabaseHelper(this)
        expenseDb = ExpenseDatabaseHelper(this)
        healthDb = ActivityDatabaseHelper(this)

        // UI
        txtTaskCount = findViewById(R.id.txtTaskCount)
        txtGrocery = findViewById(R.id.txtGrocery)
        txtExpense = findViewById(R.id.txtExpense)
        txtHealth = findViewById(R.id.txtHealth)
        txtInsight = findViewById(R.id.txtInsight)

        barChart = findViewById(R.id.barChart)
        lineChart = findViewById(R.id.lineChart)

        val txtUserEmail = findViewById<TextView>(R.id.txtUserEmail)
        val btnSettings = findViewById<ImageView>(R.id.btnSettings)
        val btnEmergency = findViewById<ImageView>(R.id.btnEmergency)

        txtUserEmail.text = intent.getStringExtra("email") ?: "user@gmail.com"

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btnEmergency.setOnClickListener {
            startActivity(Intent(this, EmergencyActivity::class.java))
        }

        // ===== NAV CARDS =====
        findViewById<LinearLayout>(R.id.cardTask).setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.cardExpense).setOnClickListener {
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.cardGrocery).setOnClickListener {
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.cardHealth).setOnClickListener {
            startActivity(Intent(this, HealthActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.cardTerms).setOnClickListener {
            startActivity(Intent(this, TermsPolicyActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.cardHelpline).setOnClickListener {
            startActivity(Intent(this, HelplineActivity::class.java))
        }

        // =====================================================
        // ⚡ QUICK ACTIONS (ADDED HERE)
        // =====================================================

        findViewById<LinearLayout>(R.id.quickAddTask)?.setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.quickAddGrocery)?.setOnClickListener {
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.quickCallHelp)?.setOnClickListener {
            startActivity(Intent(this, HelplineActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.quickMeal)?.setOnClickListener {
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }


        // BOTTOM NAV
        findViewById<TextView>(R.id.navHome).setOnClickListener {
            loadDashboard()
        }

        findViewById<TextView>(R.id.navTasks).setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        findViewById<TextView>(R.id.navGrocery).setOnClickListener {
            startActivity(Intent(this, GroceryActivity::class.java))
        }

        findViewById<TextView>(R.id.navBills).setOnClickListener {
            startActivity(Intent(this, BillsExpensesActivity::class.java))
        }

        findViewById<TextView>(R.id.navAddMeal).setOnClickListener {
            startActivity(Intent(this, MealPlannerActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadDashboard()
    }

    private fun loadDashboard() {

        val taskCount = taskDb.getAllTasks().size
        val groceryCount = groceryDb.getAllGroceries().count

        val expenses = expenseDb.getAllExpenses()
        var total = 0.0
        for (e in expenses) total += e.amount

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val bmiData = healthDb.getBMI(today)

        txtTaskCount.text = if (taskCount == 0) "No Tasks 🎉" else "$taskCount Tasks"
        txtGrocery.text = if (groceryCount == 0) "No Items 🛒" else "$groceryCount Items"
        txtExpense.text = if (total == 0.0) "RM 0.00" else "RM %.2f".format(total)
        txtHealth.text = if (bmiData != null) "BMI: %.1f".format(bmiData.first) else "BMI: --"

        val taskValue = taskCount.toFloat()
        val healthValue = (bmiData?.first ?: 0f)
        val groceryValue = groceryCount.toFloat()
        val extraValue = (total / 100).toFloat()

        barChart.setData(
            listOf(taskValue, healthValue, groceryValue, extraValue),
            listOf("Tasks", "Health", "Grocery", "Extra")
        )

        lineChart.setData(
            listOf(3f, 4f, 2f, 5f, 4f, 3f, 4f)
        )

        txtInsight.text =
            "Task completed: $taskCount\n" +
                    "Mood: ${
                        when {
                            (bmiData?.first ?: 0f) > 25 -> "Stable 🙂"
                            (bmiData?.first ?: 0f) > 20 -> "Normal 😐"
                            else -> "Low ⚠️"
                        }
                    }\n" +
                    "Streak: 4 days 🔥"
    }
}
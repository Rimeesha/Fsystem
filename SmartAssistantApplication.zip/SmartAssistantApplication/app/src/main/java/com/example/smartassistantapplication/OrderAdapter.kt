package com.example.smartassistantapplication

import android.content.Context
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream

class OrderAdapter(
    private val list:ArrayList<OrderModel>,
    private val context:Context
) : RecyclerView.Adapter<OrderAdapter.ViewHolder>() {

    class ViewHolder(view:View):RecyclerView.ViewHolder(view){
        val invoice = view.findViewById<TextView>(R.id.itemInvoice)
        val product = view.findViewById<TextView>(R.id.itemProduct)
        val price = view.findViewById<TextView>(R.id.itemPrice)
        val qty = view.findViewById<TextView>(R.id.itemQty)
        val buyer = view.findViewById<TextView>(R.id.itemBuyer)
        val phone = view.findViewById<TextView>(R.id.itemPhone)
        val address = view.findViewById<TextView>(R.id.itemAddress)
        val payment = view.findViewById<TextView>(R.id.itemPayment)
        val date = view.findViewById<TextView>(R.id.itemDate)

        val btnDelete = view.findViewById<Button>(R.id.btnDelete)
        val btnPDF = view.findViewById<Button>(R.id.btnPDF)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.order_item,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val order = list[position]

        holder.invoice.text = "Invoice: ${order.invoice}"
        holder.product.text = "Product: ${order.productName}"
        holder.price.text = "Price: ${order.price}"
        holder.qty.text = "Qty: ${order.quantity}"
        holder.buyer.text = "Buyer: ${order.buyerName}"
        holder.phone.text = "Phone: ${order.phone}"
        holder.address.text = "Address: ${order.address}"
        holder.payment.text = "Payment: ${order.payment}"
        holder.date.text = "Date: ${order.date}"

        holder.btnDelete.setOnClickListener {
            val db = OrderDatabaseHelper(context)
            if(db.deleteOrder(order.id)){
                list.removeAt(position)
                notifyDataSetChanged()
                Toast.makeText(context,"Deleted",Toast.LENGTH_SHORT).show()
            }
        }

        holder.btnPDF.setOnClickListener {
            createPDF(order)
        }
    }

    private fun createPDF(order:OrderModel){

        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(300,600,1).create()
        val page = pdf.startPage(pageInfo)

        val canvas = page.canvas
        val paint = android.graphics.Paint()

        var y = 40

        canvas.drawText("INVOICE: ${order.invoice}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Date: ${order.date}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Buyer: ${order.buyerName}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Phone: ${order.phone}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Address: ${order.address}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Payment: ${order.payment}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Product: ${order.productName}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Qty: ${order.quantity}",10f,y.toFloat(),paint)
        y+=30

        canvas.drawText("Total: ${order.price}",10f,y.toFloat(),paint)

        pdf.finishPage(page)

        val file = File(
            Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS),
            "invoice_${order.invoice}.pdf"
        )

        pdf.writeTo(FileOutputStream(file))
        pdf.close()

        Toast.makeText(context,"PDF Saved",Toast.LENGTH_LONG).show()
    }
}
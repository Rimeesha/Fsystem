package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class GroceryDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context,"GroceriesDB",null,1){

    override fun onCreate(db: SQLiteDatabase?) {

        val createTable =
            "CREATE TABLE groceries(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "item TEXT," +
                    "qty TEXT)"

        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

        db?.execSQL("DROP TABLE IF EXISTS groceries")
        onCreate(db)
    }

    fun insertGrocery(item:String, qty:String){

        val db = writableDatabase
        val values = ContentValues()

        values.put("item",item)
        values.put("qty",qty)

        db.insert("groceries",null,values)
    }

    fun getAllGroceries(): Cursor{

        val db = readableDatabase
        return db.rawQuery("SELECT * FROM groceries",null)
    }

    fun deleteGrocery(itemName:String){

        val db = writableDatabase

        db.delete(
            "groceries",
            "item=?",
            arrayOf(itemName)
        )
    }
}
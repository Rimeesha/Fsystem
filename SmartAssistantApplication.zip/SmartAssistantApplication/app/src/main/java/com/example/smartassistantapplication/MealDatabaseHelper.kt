package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

class MealDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "MealDB"
        private const val DATABASE_VERSION = 3 // increment version to force onUpgrade
        private const val TABLE_MEALS = "meals"
        private const val COLUMN_ID = "id"
        private const val COLUMN_MEAL_NAME = "mealName"
        private const val COLUMN_MEAL_TYPE = "mealType"
        private const val COLUMN_CALORIES = "calories"
        private const val COLUMN_DATE = "date"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE_MEALS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_MEAL_NAME TEXT NOT NULL,
                $COLUMN_MEAL_TYPE TEXT NOT NULL,
                $COLUMN_CALORIES INTEGER NOT NULL,
                $COLUMN_DATE TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_MEALS")
        onCreate(db)
    }

    fun insertMeal(mealName: String, mealType: String, calories: Int, date: String): Boolean {
        return try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put(COLUMN_MEAL_NAME, mealName.ifEmpty { "Unknown Meal" })
                put(COLUMN_MEAL_TYPE, mealType.ifEmpty { "Unknown Type" })
                put(COLUMN_CALORIES, calories)
                put(COLUMN_DATE, date.ifEmpty {
                    SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
                })
            }
            val result = db.insert(TABLE_MEALS, null, values)
            db.close()
            result != -1L
        } catch (e: Exception) {
            e.printStackTrace() // this will log the real reason for failure
            false
        }
    }

    fun getMealsByDate(date: String): Cursor? {
        return try {
            readableDatabase.rawQuery("SELECT * FROM $TABLE_MEALS WHERE $COLUMN_DATE=?", arrayOf(date))
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun updateMeal(id: Int, mealName: String, mealType: String, calories: Int): Boolean {
        return try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put(COLUMN_MEAL_NAME, mealName)
                put(COLUMN_MEAL_TYPE, mealType)
                put(COLUMN_CALORIES, calories)
            }
            val result = db.update(TABLE_MEALS, values, "$COLUMN_ID=?", arrayOf(id.toString()))
            db.close()
            result > 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun deleteMeal(id: Int): Boolean {
        return try {
            val db = writableDatabase
            val result = db.delete(TABLE_MEALS, "$COLUMN_ID=?", arrayOf(id.toString()))
            db.close()
            result > 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
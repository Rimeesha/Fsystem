package com.example.smartassistantapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "User.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {

        db?.execSQL(
            "CREATE TABLE users(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "fullname TEXT," +
                    "email TEXT UNIQUE," +
                    "password TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

        db?.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    // ---------------- INSERT USER ----------------
    fun insertUser(fullname: String, email: String, password: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("fullname", fullname)
        values.put("email", email)
        values.put("password", password)

        val result = db.insert("users", null, values)

        return result != -1L
    }

    // ---------------- LOGIN CHECK ----------------
    fun checkUser(email: String, password: String): Boolean {

        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE email=? AND password=?",
            arrayOf(email, password)
        )

        val exists = cursor.count > 0
        cursor.close()

        return exists
    }

    // ---------------- CHECK EMAIL EXISTS ----------------
    fun checkEmailExists(email: String): Boolean {

        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE email=?",
            arrayOf(email)
        )

        val exists = cursor.count > 0
        cursor.close()

        return exists
    }

    // ---------------- FORGOT PASSWORD (RESET PASSWORD) ----------------
    fun updatePassword(email: String, newPassword: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("password", newPassword)

        val result = db.update(
            "users",
            values,
            "email=?",
            arrayOf(email)
        )

        return result > 0
    }

    // ---------------- UPDATE PROFILE NAME ----------------
    fun updateProfile(email: String, newFullName: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("fullname", newFullName)

        val result = db.update(
            "users",
            values,
            "email=?",
            arrayOf(email)
        )

        return result > 0
    }

    // ---------------- UPDATE EMAIL ----------------
    fun updateEmail(oldEmail: String, newEmail: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("email", newEmail)

        val result = db.update(
            "users",
            values,
            "email=?",
            arrayOf(oldEmail)
        )

        return result > 0
    }

    // ---------------- GET FULL NAME ----------------
    fun getFullName(email: String): String {

        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT fullname FROM users WHERE email=?",
            arrayOf(email)
        )

        var name = ""

        if (cursor.moveToFirst()) {
            name = cursor.getString(0)
        }

        cursor.close()

        return name
    }
}